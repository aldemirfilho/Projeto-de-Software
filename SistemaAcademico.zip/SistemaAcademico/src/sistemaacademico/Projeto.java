package sistemaacademico;

import java.util.ArrayList;

public class Projeto {
    private String titulo;
    private int dia_inicio;
    private int mes_inicio;
    private int ano_inicio;
    private int dia_final;
    private int mes_final;
    private int ano_final;
    private String Ag_financiadora;
    private int valor_financiado;
    private String objetivo;
    private String descricao;
    private String status;
    private boolean fim;
    
    java.util.ArrayList<String> Participantes = new java.util.ArrayList<String>();
    java.util.ArrayList<String> Publicacoes = new java.util.ArrayList<String>();

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getDia_inicio() {
        return dia_inicio;
    }

    public void setDia_inicio(int dia_inicio) {
        this.dia_inicio = dia_inicio;
    }

    public int getMes_inicio() {
        return mes_inicio;
    }

    public void setMes_inicio(int mes_inicio) {
        this.mes_inicio = mes_inicio;
    }

    public int getAno_inicio() {
        return ano_inicio;
    }

    public void setAno_inicio(int ano_inicio) {
        this.ano_inicio = ano_inicio;
    }

    public int getDia_final() {
        return dia_final;
    }

    public void setDia_final(int dia_final) {
        this.dia_final = dia_final;
    }

    public int getMes_final() {
        return mes_final;
    }

    public void setMes_final(int mes_final) {
        this.mes_final = mes_final;
    }

    public int getAno_final() {
        return ano_final;
    }

    public void setAno_final(int ano_final) {
        this.ano_final = ano_final;
    }

    public String getAg_financiadora() {
        return Ag_financiadora;
    }

    public void setAg_financiadora(String Ag_financiadora) {
        this.Ag_financiadora = Ag_financiadora;
    }

    public int getValor_financiado() {
        return valor_financiado;
    }

    public void setValor_financiado(int valor_financiado) {
        this.valor_financiado = valor_financiado;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isFim() {
        return fim;
    }

    public void setFim(boolean fim) {
        this.fim = fim;
    }

    public ArrayList<String> getParticipantes() {
        return Participantes;
    }

    public void setParticipantes(ArrayList<String> Participantes) {
        this.Participantes = Participantes;
    }

    public ArrayList<String> getPublicacoes() {
        return Publicacoes;
    }

    public void setPublicacoes(ArrayList<String> publicacoes) {
        this.Publicacoes = publicacoes;
    }
}
