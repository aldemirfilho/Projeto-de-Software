package sistemaacademico;

import java.util.ArrayList;

public class Publicacao {
    private String titulo;
    private String nome_conferencia;
    private int ano_publicacao;
    private String projeto_ass;
    
    java.util.ArrayList<String> Autores = new java.util.ArrayList<String>();

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNome_conferencia() {
        return nome_conferencia;
    }

    public void setNome_conferencia(String nome_conferencia) {
        this.nome_conferencia = nome_conferencia;
    }

    public int getAno_publicacao() {
        return ano_publicacao;
    }

    public void setAno_publicacao(int ano_publicacao) {
        this.ano_publicacao = ano_publicacao;
    }

    public String getProjeto_ass() {
        return projeto_ass;
    }

    public void setProjeto_ass(String projeto_ass) {
        this.projeto_ass = projeto_ass;
    }

    public ArrayList<String> getAutores() {
        return Autores;
    }

    public void setAutores(ArrayList<String> autores) {
        this.Autores = autores;
    }
}
