package sistemaacademico;

import java.util.ArrayList;

public class Colaborador {
    private String tipo_colaborador;
    private String nome;
    private String email;
    
    java.util.ArrayList<String> Publicacoes = new java.util.ArrayList<String>();
    java.util.ArrayList<String> Projetos = new java.util.ArrayList<String>();
    java.util.ArrayList<String> Orientacoes = new java.util.ArrayList<String>();

    public String getTipo_colaborador() {
        return tipo_colaborador;
    }

    public void setTipo_colaborador(String tipo_colaborador) {
        this.tipo_colaborador = tipo_colaborador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ArrayList<String> getPublicacoes() {
        return Publicacoes;
    }

    public void setPublicacoes(ArrayList<String> publicacoes) {
        this.Publicacoes = publicacoes;
    }

    public ArrayList<String> getProjetos() {
        return Projetos;
    }

    public void setProjetos(ArrayList<String> projetos) {
        this.Projetos = projetos;
    }

    public ArrayList<String> getOrientacoes() {
        return Orientacoes;
    }

    public void setOrientacoes(ArrayList<String> orientacoes) {
        this.Orientacoes = orientacoes;
    }
}
