package sistemaacademico;

import java.util.Scanner;

public class SistemaAcademico {
    public static void main(String[] args) 
    {
        System.out.println("           Bem vindo ao Sistema de Gestão de Produtividade Acadêmica");
        System.out.println("1. Cadastrar Colaborador;");
        System.out.println("2. Lançar publicação;");
        System.out.println("3. Editar Publicações;");
        System.out.println("4. Criar ou editar projetos;");
        System.out.println("5. Consultar colaborador;");
        System.out.println("6. Consultar projeto;");
        System.out.println("7. Produção acadêmica do Laboratório;");
        
        Scanner input = new Scanner(System.in);
        int opcao = 0;
        
        String lixo = new String();
        
        java.util.ArrayList<Colaborador> Colaboradores = new java.util.ArrayList<Colaborador>();
        java.util.ArrayList<Publicacao> Publicacoes = new java.util.ArrayList<Publicacao>();
        java.util.ArrayList<Projeto> Projetos = new java.util.ArrayList<Projeto>();
      
        while(opcao != 10)
        {
            System.out.println();
            System.out.print("Digite a opção que deseja.\nResp: ");
            opcao = input.nextInt();
            System.out.println();
            if(opcao == 1)
            {
                int control1 = 1;
                
                Colaborador colaborador = new Colaborador();
                
                lixo = input.nextLine();
                
                while(control1 == 1)
                {
                    int igual1 = 0, k;
                    System.out.println("Digite o nome do colaborador:");
                    colaborador.setNome(input.nextLine());
                    if(Colaboradores.size() == 0)
                    {
                        break;
                    }
                    for(k = 0; k < Colaboradores.size(); k++)
                    {
                        if(Colaboradores.get(k).getNome().equals(colaborador.getNome()))
                        {
                            System.out.println("Este nome ja esta sendo usado, dê um novo nome para este colaborador.");
                            igual1 = 1;
                        }
                        if((k == Colaboradores.size() - 1) && (igual1 == 0))
                        {
                            control1 = 0;
                        }
                    }
                }
                System.out.println("Digite o E-mail do colaborador:");
                colaborador.setEmail(input.nextLine());
                System.out.println("Digite o tipo de colaborador(aluno de graduacao, aluno de mestrado, aluno de doutorado, professor, pesquisador):");
                colaborador.setTipo_colaborador(input.nextLine());
                
                Colaboradores.add(colaborador);
            }
            if(Colaboradores.size() != 0)
            {
                if(opcao == 2)
                {
                    lixo = input.nextLine();

                    int ass, i, j, k, g, f, autores, control2_1 = 1;
                    String projeto, nome_autor;

                    Publicacao publicacao = new Publicacao();
                    while(control2_1 == 1)
                    {
                        int igual = 0;
                        System.out.println("Digite o Titulo da publicação:");
                        publicacao.setTitulo(input.nextLine());
                        if(Publicacoes.size() == 0)
                        {
                            break;
                        }
                        for(k = 0; k < Publicacoes.size(); k++)
                        {
                            if(Publicacoes.get(k).getTitulo().equals(publicacao.getTitulo()))
                            {
                                System.out.println("Este titulo ja esta sendo usado, dê um novo titulo para esta publicaçâo.");
                                igual = 1;
                            }
                            if((k == Publicacoes.size() - 1) && (igual == 0))
                            {
                                control2_1 = 0;
                            }
                        }
                    }
                    //Publicacoes.add(publicacao);
                    System.out.println("Digite o nome da conferencia");
                    publicacao.setNome_conferencia(input.nextLine());
                    System.out.println("Digite o ano de publicação");
                    publicacao.setAno_publicacao(input.nextInt());
                    System.out.print("Esta publicação está associada á algum projeto?\nSIM: Digite 1\nNAO: Digite 0\nResp: ");
                    ass = input.nextInt();
                    System.out.println();
                    if(ass == 1)
                    {
                        lixo = input.nextLine();
                        if(Projetos.size() == 0)
                        {
                            System.out.println("Não há projetos sendo realizados no momento.");
                            System.out.println();
                            publicacao.setProjeto_ass("0");
                        }
                        else
                        {
                            int control2_2 = 0;
                            for(i = 0; i < Projetos.size(); i++)
                            {
                                System.out.println(Projetos.get(i).getTitulo());
                            }
                            System.out.println("Digite o nome do projeto associado:");
                            projeto = input.nextLine();
                            for(i = 0; i < Projetos.size(); i++)
                            {
                                if((Projetos.get(i).getTitulo().equals(projeto)) && (Projetos.get(i).getStatus().equals("em andamento")))
                                {
                                    Projetos.get(i).getPublicacoes().add(publicacao.getTitulo());
                                    publicacao.setProjeto_ass(projeto);
                                    control2_2 = 1;
                                }
                                else if((Projetos.get(i).getTitulo().equals(projeto)) && (!(Projetos.get(i).getStatus().equals("em andamento"))))
                                {
                                    System.out.println("O projeto não possui o status 'em andamento' logo não pode ter tal projeto associado.");
                                    control2_2 = 1;
                                }
                                if((i == Projetos.size() - 1) && (control2_2 == 0))
                                {
                                    System.out.println("Projeto digitado incorretamente ou não existe.");
                                }
                            }
                        }
                    }
                    if(ass == 0)
                    {
                        publicacao.setProjeto_ass("0");
                    }
                    int control2_3;
                    System.out.println("Digite a quantidade de autores que esta publicaçâo possui:");
                    autores = input.nextInt();
                    lixo = input.nextLine();
                    System.out.println("Digite o(s) nomes(s) do(s) autor(es):");
                    for(j = 0; j < autores; j++)
                    {
                        control2_3 = 0;
                        nome_autor = input.nextLine();
                        for(f = 0; f < Colaboradores.size(); f++)
                        {
                            if(Colaboradores.get(f).getNome().equals(nome_autor))
                            {
                                publicacao.getAutores().add(nome_autor);
                                Colaboradores.get(f).getPublicacoes().add(publicacao.getTitulo());
                                control2_3 = 1;
                            }
                            else if((f == Colaboradores.size() - 1) && (control2_3 == 0))
                            {
                                j--;
                                System.out.println("Colaborador " + nome_autor + ", não emcontrado, tente novamente.");
                            }
                        }
                    }
                    //System.out.println("autores " + publicacao.getAutores());
                    Publicacoes.add(publicacao);
                }
                if(opcao == 3)
                {
                    lixo = input.nextLine();
                    int i, j, k, h, control3 = 1;
                    String publicacao, escolha;
                    System.out.println("Publicações existentes:");
                    for(i = 0; i < Publicacoes.size(); i++)
                    {
                        System.out.println("-" + Publicacoes.get(i).getTitulo());
                    }
                    System.out.println("Digite o nome da publicação que deseja editar: ");
                    publicacao = input.nextLine();
                    for(i = 0; i < Publicacoes.size(); i++)
                    {
                        if(Publicacoes.get(i).getTitulo().equals(publicacao))
                        {
                            System.out.println("Digite o que deseja editar na publicação(titulo, conferencia, ano, projeto associado, autores):");
                            escolha = input.nextLine();

                            if(escolha.equals("titulo"))
                            {
                                String new_name, old_name;
                                old_name = Publicacoes.get(i).getTitulo();
                               //System.out.println("titulo antes " + Publicacoes.get(i).getTitulo());
                                while(control3 == 1)
                                {
                                    int igual = 0;
                                    System.out.println("Digite o o novo Titulo da publicação:");
                                    new_name = input.nextLine();
                                    for(j = 0; j < Publicacoes.size(); j++)
                                    {
                                        if(Publicacoes.get(j).getTitulo().equals(new_name))
                                        {
                                            System.out.println("Este titulo ja esta sendo usado, dê um novo titulo para esta publicaçâo.");
                                            igual = 1;
                                        }
                                        if((j == Publicacoes.size() - 1) && (igual == 0))
                                        {
                                            Publicacoes.get(i).setTitulo(new_name);
                                            for(k = 0; k < Colaboradores.size(); k++)
                                            {
                                                for(h = 0; h < Colaboradores.get(k).getPublicacoes().size(); h++)
                                                {
                                                    if(Colaboradores.get(k).getPublicacoes().get(h).equals(old_name))
                                                    {
                                                        //System.out.println("nome antigo " + old_name);
                                                        Colaboradores.get(k).getPublicacoes().remove(h);
                                                        Colaboradores.get(k).getPublicacoes().add(new_name);
                                                        //System.out.println();
                                                        //System.out.println("nome" + Colaboradores.get(k).getNome() + Colaboradores.get(k).getPublicacoes());
                                                    }
                                                }
                                            }
                                            for(k = 0; k < Projetos.size(); k++)
                                            {
                                                for(h = 0; h < Projetos.get(k).getPublicacoes().size(); h++)
                                                {
                                                    if(Projetos.get(k).getPublicacoes().get(h).equals(old_name))
                                                    {
                                                        //System.out.println("nome antigo " + old_name);
                                                        Projetos.get(k).getPublicacoes().remove(h);
                                                        Projetos.get(k).getPublicacoes().add(new_name);
                                                        //System.out.println("nome" + Projetos.get(k).getTitulo() + Projetos.get(k).getPublicacoes());
                                                    }
                                                }
                                            }
                                            control3 = 0;
                                        }
                                    }
                                }
                                //System.out.println("titulo depois " + Publicacoes.get(i).getTitulo());
                            }
                            if(escolha.equals("conferencia"))
                            {
                                //System.out.println("conferencia antes " + Publicacoes.get(i).getNome_conferencia());
                                System.out.println("Digite o nome da nova conferência:");
                                Publicacoes.get(i).setNome_conferencia(input.nextLine());
                                //System.out.println("conferencia dps " + Publicacoes.get(i).getNome_conferencia());
                            }
                            if(escolha.equals("ano"))
                            {
                                //System.out.println("ano antes " + Publicacoes.get(i).getAno_publicacao());
                                System.out.println("Digite o nome do novo ano de publicação:");
                                Publicacoes.get(i).setAno_publicacao(input.nextInt());
                                lixo = input.nextLine();
                                //System.out.println("ano dps " + Publicacoes.get(i).getAno_publicacao());
                            }
                            if(escolha.equals("projeto associado"))
                            {
                                int t, resp, subst = 0, control34 = 0;
                                String nome_proj, old_proj = null;
                                if(Projetos.size() == 0)
                                {
                                    System.out.println("Não há projetos sendo realizados no momento.");
                                }
                                else
                                {
                                    System.out.print("Voce deseja remover um projeto relacionado a esta publicação ou adicionar um projeto?\nAdicionar: 1\nRemover: 2\nResp: ");
                                    resp = input.nextInt();
                                    lixo = input.nextLine();
                                    System.out.println();
                                    if(resp == 1)
                                    {
                                        if(!(Publicacoes.get(i).getProjeto_ass().equals("0")))
                                        {
                                            System.out.print("A publicação já possui um projeto associado, deseja substituir?\nSIM: Digite 1\nNAO: Digite 0\nresp: ");
                                            old_proj = Publicacoes.get(i).getProjeto_ass();
                                            subst = input.nextInt();
                                            lixo = input.nextLine();
                                        }
                                        if((Publicacoes.get(i).getProjeto_ass().equals("0")) || (subst == 1))
                                        {
                                            int q;
                                            System.out.println("Projetos existentes:");
                                            for(q = 0; q < Projetos.size(); q++)
                                            {
                                                System.out.println("-" + Projetos.get(q).getTitulo());
                                            }
                                            System.out.println("Insira o titulo do projeto que deseja relacionar à publicação:");
                                            nome_proj = input.nextLine();
                                            for(k = 0; k < Projetos.size(); k++)
                                            {
                                                if(Projetos.get(k).getTitulo().equals(nome_proj))
                                                {
                                                    Projetos.get(k).getPublicacoes().add(Publicacoes.get(i).getTitulo());
                                                    control34 = 1;
                                                }
                                                else if((k == Projetos.size() - 1) && (control34 == 0))
                                                {
                                                    System.out.println("Projeto desejado não existe ou foi digitado incorretamente, tente novamente.");
                                                }
                                            }
                                            if(subst == 1)
                                            {
                                                for(k = 0; k < Projetos.size(); k++)
                                                {
                                                    if(Projetos.get(k).getTitulo().equals(old_proj))
                                                    {
                                                        for(t = 0; t < Projetos.get(k).getPublicacoes().size(); t++)
                                                        {
                                                            if(Projetos.get(k).getPublicacoes().get(t).equals(Publicacoes.get(i).getTitulo()))
                                                            {
                                                                Projetos.get(k).getPublicacoes().remove(t);
                                                                //System.out.println("apagou");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            Publicacoes.get(i).setProjeto_ass(nome_proj);
                                        }
                                    }
                                    else if(resp == 2)
                                    {
                                        String aux = Publicacoes.get(i).getProjeto_ass();
                                        if(!Publicacoes.get(i).getProjeto_ass().equals(0))
                                        {
                                            for(k = 0; k < Projetos.size(); k++)
                                            {
                                                if(Projetos.get(k).getTitulo().equals(aux))
                                                {
                                                    for(j= 0; j < Projetos.get(k).getPublicacoes().size(); j++)
                                                    {
                                                        if(Projetos.get(k).getPublicacoes().get(j).equals(Publicacoes.get(i).getTitulo()))
                                                        {
                                                            Projetos.get(k).getPublicacoes().remove(j);
                                                        }
                                                    }
                                                }
                                            }
                                            Publicacoes.get(i).setProjeto_ass("0");
                                        }
                                        else if((Publicacoes.get(i).getProjeto_ass().equals(0)))
                                        {
                                            System.out.println("A publicação não está relacionada a nenhum projeto.");
                                        }
                                    }
                                }
                            }
                            if(escolha.equals("autores"))
                            {
                                //System.out.println("autores antes" + Publicacoes.get(i).getAutores());
                                int func, e, f, g, control35 = 0;
                                String nome_autor;
                                System.out.print("Você deseja remover um adicionar um novo autor?\nAdicionar: Digite 1\nRemover: Digite 2\nResp: ");
                                func = input.nextInt();
                                System.out.println();
                                lixo = input.nextLine();
                                if(func == 1)
                                {
                                    System.out.println("Colaboradores existentes:");
                                    for(e = 0; e < Colaboradores.size(); e++)
                                    {
                                        System.out.println("-" + Colaboradores.get(e).getNome());
                                    }
                                    System.out.println("Digite o nome do autor que deseja adicionar:");
                                    nome_autor = input.nextLine();
                                    for(e = 0; e < Colaboradores.size(); e++)
                                    {
                                        if(Colaboradores.get(e).getNome().equals(nome_autor))
                                        {
                                            Publicacoes.get(i).getAutores().add(nome_autor);
                                            Colaboradores.get(e).getPublicacoes().add(Publicacoes.get(i).getTitulo());
                                            control35 = 1;
                                        }
                                        else if((e == Colaboradores.size() - 1) && (control35 == 0))
                                        {
                                            System.out.println("Colaborador não existe ou digitado incorretamente.");
                                        }
                                    }
                                }
                                if(func == 2)
                                {
                                    System.out.println("Digite o nome do autor que deseja remover:");
                                    nome_autor = input.nextLine();
                                    for(e = 0; e < Publicacoes.get(i).getAutores().size(); e++)
                                    {
                                        if(Publicacoes.get(i).getAutores().get(e).equals(nome_autor))
                                        {
                                            //System.out.println("aquiii");
                                            Publicacoes.get(i).getAutores().remove(e);
                                            control35 = 1;
                                        }
                                        if((e == Publicacoes.get(i).getAutores().size() - 1) && (control35 == 0)) 
                                        {
                                            System.out.println("autor não existe nessa publicação ou digitado incorretamente.");
                                        }
                                    }
                                    //System.out.println("autores depois" + Publicacoes.get(i).getAutores());
                                    for(f = 0; f < Colaboradores.size(); f++)
                                    {
                                        if(Colaboradores.get(f).getNome().equals(nome_autor))
                                        {
                                            for(g = 0; g < Colaboradores.get(f).getPublicacoes().size(); g++)
                                            {
                                                if(Colaboradores.get(f).getPublicacoes().get(g).equals(Publicacoes.get(i).getTitulo()));
                                                {
                                                    Colaboradores.get(f).getPublicacoes().remove(g);
                                                }
                                            }
                                        }
                                    }
                                }
                                //System.out.println("autores depois" + Publicacoes.get(i).getAutores());
                            }
                        }
                    }
                }
                if(opcao == 4)
                {
                    int resp;
                    System.out.print("Você deseja criar ou editar projetos?\nCriar: Digite 1\nEditar: Digite 2\nResp: ");
                    resp = input.nextInt();
                    System.out.println();
                    if(resp == 1)
                    {
                        lixo = input.nextLine();
                        int control41 = 1, k;

                        Projeto projeto = new Projeto();

                        while(control41 == 1)
                        {
                            int igual = 0;
                            System.out.println("Digite o Titulo do projeto:");
                            projeto.setTitulo(input.nextLine());
                            if(Projetos.size() == 0)
                            {
                                break;
                            }
                            for(k = 0; k < Projetos.size(); k++)
                            {
                                if(Projetos.get(k).getTitulo().equals(projeto.getTitulo()))
                                {
                                    System.out.println("Este titulo ja esta sendo usado, dê um novo titulo para esta publicaçâo.");
                                    igual = 1;
                                }
                                if((k == Projetos.size() - 1) && (igual == 0))
                                {
                                    control41 = 0;
                                }
                            }
                        }
                        System.out.println("Digite a data de inicio do projeto: ");
                        System.out.println("Dia: "); 
                        projeto.setDia_inicio(input.nextInt());
                        System.out.println("Mês: "); 
                        projeto.setMes_inicio(input.nextInt());
                        System.out.println("Ano: "); 
                        projeto.setAno_inicio(input.nextInt());
                        System.out.println("Digite a data prevista para fim do projeto: ");
                        System.out.println("Dia: "); 
                        projeto.setDia_final(input.nextInt());
                        System.out.println("Mês: "); 
                        projeto.setMes_final(input.nextInt());
                        System.out.println("Ano: "); 
                        projeto.setAno_final(input.nextInt());
                        lixo = input.nextLine();
                        System.out.println("Digite a Agencia Financiadora: ");
                        projeto.setAg_financiadora(input.nextLine());
                        System.out.println("Digite o valor financiado: ");
                        projeto.setValor_financiado(input.nextInt());
                        lixo = input.nextLine();
                        System.out.println("Digite o Objetivo do Projeto: ");
                        projeto.setObjetivo(input.nextLine());
                        System.out.println("Digite a Descrição do projeto: ");
                        projeto.setDescricao(input.nextLine());
                        System.out.println("Como o o projeto acaba de ser criado, seu status no momento é 'em elaboracao', isso impede de relacionar publicacoes ao projeto, porem futuramente isso pode ser alterado na funcao 4 'editar projetos'.");
                        projeto.setStatus("em elaboracao");
                        int qntd, g, f, control42 = 0, cont4 = 0;
                        String nome, proj_grad;
                        System.out.println("inclua os participantes do projeto, quantos são incluindo o professor?");
                        qntd = input.nextInt();
                        lixo = input.nextLine(); 
                        System.out.println("Digite o(s) nome(s) do(s) participante(es):");
                        for(g = 0; g < qntd; g++)
                        {
                            nome = input.nextLine();
                            for(f = 0; f < Colaboradores.size(); f++)
                            {
                                if(Colaboradores.get(f).getNome().equals(nome))
                                {
                                    projeto.getParticipantes().add(nome);
                                    Colaboradores.get(f).getProjetos().add(projeto.getTitulo());
                                    if(Colaboradores.get(f).getTipo_colaborador().equals("professor"))
                                    {
                                        cont4++;
                                        Colaboradores.get(f).getOrientacoes().add(projeto.getTitulo());
                                    }
                                    control42 = 1;
                                }
                                else if((f == Colaboradores.size() - 1) && (control42 == 0))
                                {
                                    g--;
                                    System.out.println("Colaborador " + nome + ", não emcontrado, tente novamente.");
                                }
                            }
                        }
                        if(cont4 == 0)
                        {
                            System.out.println("Nenhum professor está cadastrado no projeto, adicione um professor usando a opcao 4 'editar', para seguir com este projeto.");
                            Projetos.add(projeto);
                        }
                        else
                        {
                            Projetos.add(projeto);
                        }
                        //System.out.println(projeto.getParticipantes());
                    }
                    if(resp == 2)
                    {
                        if(Projetos.size() == 0)
                        {
                            System.out.println("Ainda não existem projetos em atividade");
                        }
                        else
                        {
                            int d, w, y, q, control43 = 0;
                            lixo = input.nextLine();
                            String resp2, old_name;
                            System.out.println("Projetos esistentes:");
                            for(d = 0; d < Projetos.size(); d++)
                            {
                                System.out.println("-" + Projetos.get(d).getTitulo());
                            }
                            System.out.println();
                            System.out.println("Digite o nome do projeto que deseja editar");
                            old_name = input.nextLine();
                            System.out.println();
                            for(d = 0; d < Projetos.size(); d++)
                            {
                                if(Projetos.get(d).getTitulo().equals(old_name))
                                {
                                    System.out.print("Digite a opcao que deseja editar no projeto:\n-titulo\n-dia inicio\n-mes inicio\n-ano inicio\n-dia final\n-mes final\n-ano final\n-agencia financiadora\n-valor financiado\n-objetivo\n-descricao\n-status\n-publicacoes\n-participantes\nResp: ");
                                    resp2 = input.nextLine();
                                    System.out.println();
                                    if(resp2.equals("titulo"))
                                    {
                                        System.out.println("Digite o novo titulo:");
                                        String new_name = input.nextLine();
                                        for(w = 0; w < Colaboradores.size(); w++)
                                        {
                                            for(y = 0; y < Colaboradores.get(w).getProjetos().size(); y++)
                                            {
                                                if(Colaboradores.get(w).getProjetos().get(y).equals(old_name))
                                                {
                                                    Colaboradores.get(w).getProjetos().remove(y);
                                                    Colaboradores.get(w).getProjetos().add(new_name);
                                                    if(Colaboradores.get(w).getTipo_colaborador().equals("professor"))
                                                    {
                                                        for(q = 0; q < Colaboradores.get(w).getOrientacoes().size(); q++)
                                                        {
                                                            if(Colaboradores.get(w).getOrientacoes().get(q).equals(old_name))
                                                            {
                                                                Colaboradores.get(w).getOrientacoes().remove(q);
                                                                Colaboradores.get(w).getOrientacoes().add(new_name);
                                                            }
                                                        }
                                                    }
                                                }
                                                //System.out.println(Colaboradores.get(w).getProjetos());
                                                //System.out.println(Colaboradores.get(w).getOrientacoes());
                                            }
                                        }
                                        //System.out.println(old_name);
                                        //System.out.println(Publicacoes.size());
                                        //System.out.println(Publicacoes.get(0).getProjeto_ass());
                                        for(w = 0; w < Publicacoes.size(); w++)
                                        {
                                            if(Publicacoes.get(w).getProjeto_ass().equals(old_name))
                                            {
                                                //System.out.println("aquiiiiiii");
                                                Publicacoes.get(w).setProjeto_ass(new_name);
                                                //System.out.println(Publicacoes.get(w).getProjeto_ass());
                                            }
                                        }
                                        Projetos.get(d).setTitulo(new_name);
                                    }
                                    if(resp2.equals("dia inicio"))
                                    {
                                        System.out.println("Digite o novo dia inicio:");
                                        Projetos.get(d).setDia_inicio(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("mes inicio"))
                                    {
                                        System.out.println("Digite o novo mes inicio:");
                                        Projetos.get(d).setMes_inicio(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("ano inicio"))
                                    {
                                        System.out.println("Digite o novo ano inicio:");
                                        Projetos.get(d).setAno_inicio(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("dia final"))
                                    {
                                        System.out.println("Digite o novo dia final:");
                                        Projetos.get(d).setDia_final(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("mes final"))
                                    {
                                        System.out.println("Digite o novo mes final:");
                                        Projetos.get(d).setMes_final(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("ano final"))
                                    {
                                        System.out.println("Digite o novo ano final:");
                                        Projetos.get(d).setAno_final(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("agencia financiadora"))
                                    {
                                        System.out.println("Digite a Nova Agencia Financiadora");
                                        Projetos.get(d).setAg_financiadora(input.nextLine());
                                    }
                                    if(resp2.equals("valor financiado"))
                                    {
                                        System.out.println("Digite a Novo Valor Financiado");
                                        Projetos.get(d).setValor_financiado(input.nextInt());
                                        lixo = input.nextLine();
                                    }
                                    if(resp2.equals("objetivo"))
                                    {
                                        System.out.println("Digite o Novo Objetivo");
                                        Projetos.get(d).setObjetivo(input.nextLine());
                                    }
                                    if(resp2.equals("descricao"))
                                    {
                                        System.out.println("Digite a Nova Descricao");
                                        Projetos.get(d).setDescricao(input.nextLine());
                                    }
                                    if(resp2.equals("status"))
                                    {
                                        int cont1, cont2, z, p,cont3;
                                        cont1 = cont2 = cont3 = 0;
                                        if(Projetos.get(d).getStatus().equals("em elaboracao"))
                                        {
                                            if(!(Projetos.get(d).getTitulo().equals(null)))
                                            {
                                                System.out.println("titulo OK");
                                            }
                                            else
                                            {
                                                System.out.println("titulo vazio");
                                                cont1++;
                                            }
                                            if(!(Projetos.get(d).getAg_financiadora().equals(null)))
                                            {
                                                System.out.println("Ag. financiadora OK");
                                            }
                                            else
                                            {
                                                System.out.println("Ag. financiadora vazia");
                                                cont1++;
                                            }
                                            if(!(Projetos.get(d).getObjetivo().equals(null)))
                                            {
                                                System.out.println("Objetivo OK");
                                            }
                                            else
                                            {
                                                System.out.println("Objetivo vazio");
                                                cont1++;
                                            }
                                            if(!(Projetos.get(d).getDescricao().equals(null)))
                                            {
                                                System.out.println("Descricao OK");
                                            }
                                            else
                                            {
                                                System.out.println("Descricao vazia");
                                                cont1++;
                                            }
                                            if(!(Projetos.get(d).getStatus().equals(null)))
                                            {
                                                System.out.println("Status OK");
                                                System.out.println("estado: " + Projetos.get(d).getStatus());
                                                if(Projetos.get(d).getStatus().equals("em elaboracao"))
                                                {
                                                    for(z = 0; z < Projetos.get(d).getParticipantes().size(); z++)
                                                    {
                                                        for(p = 0; p < Colaboradores.size();p++)
                                                        {
                                                            if(Projetos.get(d).getParticipantes().get(z).equals(Colaboradores.get(p).getNome()))
                                                            {
                                                                if(Colaboradores.get(p).getTipo_colaborador().equals("professor"))
                                                                {
                                                                    cont3++;
                                                                }
                                                            }
                                                        }  
                                                    }
                                                    if(cont3 == 0 ) 
                                                    {
                                                        System.out.println("Adicione um professor antes de atualizar o status");
                                                        cont1++;
                                                    }
                                                }
                                            }
                                            if(cont1 != 0)
                                            {
                                                System.out.println("Para mudar o status de 'em elaboração' para 'em andamento' corrija os erros acima.");
                                            }
                                            else
                                            {
                                                System.out.println("Digite o Novo Status(em elaboracao, em andamento, concluido):");
                                                Projetos.get(d).setStatus(input.nextLine());
                                            }
                                        }
                                        if(Projetos.get(d).getStatus().equals("em andamento"))
                                        {
                                            if(Projetos.get(d).getPublicacoes().size() != 0)
                                            {
                                                int respp;
                                                System.out.println("Deseja o Novo Status de concluido\nSIM: Digite 1\nNAO: Digite 2\nResp: ");
                                                respp = input.nextInt();
                                                lixo = input.nextLine();
                                                if(respp == 1)
                                                {
                                                    Projetos.get(d).setStatus("concluido");
                                                }
                                            }
                                            else
                                            {
                                                System.out.println("obs: O projeto não possui publicações para ser concluido.");
                                            }
                                        }
                                        if(Projetos.get(d).getStatus().equals("concluido"))
                                        {
                                            System.out.println("O projeto esta concluido!");
                                        }
                                    }
                                    if(resp2.equals("publicacoes"))
                                    {
                                        int resp3, r, control44 = 0;
                                        System.out.print("Você deseja adicionar ou remover uma publicação?\nAdicionar: Digite 1\nRemover: Digite 2\nResp: ");
                                        resp3 = input.nextInt();
                                        System.out.println();
                                        if(resp3 == 1)
                                        {
                                            lixo = input.nextLine();
                                            String nome_pub;
                                            System.out.println("Publicacoes existentes:");
                                            for(w = 0; w < Publicacoes.size(); w++)
                                            {
                                                System.out.println("-" + Publicacoes.get(w).getTitulo());
                                            }
                                            System.out.println("Digite o nome da pulicação que deseja adicionar:");
                                            nome_pub = input.nextLine();
                                            //if diferente de 0
                                            for(r = 0; r < Publicacoes.size(); r++)
                                            {
                                                if(Publicacoes.get(r).getTitulo().equals(nome_pub))
                                                {
                                                    if(Publicacoes.get(r).getProjeto_ass().equals("0"))
                                                    {
                                                        if(Projetos.get(d).getStatus().equals("em andamento"))
                                                        {
                                                            Publicacoes.get(r).setProjeto_ass(Projetos.get(d).getTitulo());
                                                            Projetos.get(d).getPublicacoes().add(nome_pub);
                                                        }
                                                        else
                                                        {
                                                            System.out.println("O projeto não possui status 'em andamento', tente novamente.");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        int resp31, x, z;
                                                        String old_proj;
                                                        System.out.println("Esta publicação ja está associada a um projeto, deseja mudar a associação?\nSIM: Digite 1\nNAO: Digite 2\nResp: ");
                                                        resp31 = input.nextInt();
                                                        lixo = input.nextLine();
                                                        old_proj = Publicacoes.get(r).getProjeto_ass();
                                                        if(resp31 == 1)
                                                        {
                                                            for(x = 0; x < Projetos.size(); x++)
                                                            {
                                                                if(Projetos.get(x).getTitulo().equals(old_proj))
                                                                {
                                                                    for(z = 0; z < Projetos.get(x).getPublicacoes().size(); z++)
                                                                    {
                                                                        if(Projetos.get(x).getPublicacoes().get(z).equals(nome_pub))
                                                                        {
                                                                             Projetos.get(x).getPublicacoes().remove(z);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            if(Projetos.get(d).getStatus().equals("em andamento"))
                                                            {
                                                                Publicacoes.get(r).setProjeto_ass(Projetos.get(d).getTitulo());
                                                                Projetos.get(d).getPublicacoes().add(nome_pub);
                                                            }
                                                            else
                                                            {
                                                                System.out.println("O projeto não possui status 'em andamento'.");
                                                            }
                                                        }
                                                        if(resp31 == 2)
                                                        {
                                                            System.out.println("Associação mantida");
                                                        }
                                                    }
                                                    control44 = 1;
                                                }
                                                else if((r == Publicacoes.size() - 1) && (control44 == 0))
                                                {
                                                    System.out.println("Publicacao não encontrada, tente novamente.");
                                                }
                                            }
                                        }
                                        if(resp3 == 2)
                                        {
                                            lixo = input.nextLine();
                                            int s, e, control45, control452;
                                            control45 = control452 = 0;
                                            String nome_pub;
                                            System.out.println("Publicacoes relacionadas :");
                                            for(w = 0; w < Projetos.get(d).getPublicacoes().size(); w++)
                                            {
                                                System.out.println("-" + Projetos.get(d).getPublicacoes().get(w));
                                            }
                                            System.out.println("Digite o nome da publicação que deseja remover:");
                                            nome_pub = input.nextLine();
                                            for(s = 0; s < Publicacoes.size(); s++)
                                            {
                                                if(Publicacoes.get(s).getTitulo().equals(nome_pub))
                                                {
                                                    for(e = 0; e < Projetos.get(d).getPublicacoes().size(); e++)
                                                    {
                                                        if(Projetos.get(d).getPublicacoes().get(e).equals(nome_pub))
                                                        {
                                                            Projetos.get(d).getPublicacoes().remove(e);
                                                            Publicacoes.get(s).setProjeto_ass("0");
                                                            control452 = 1;
                                                        }
                                                        else if((e == Projetos.get(d).getPublicacoes().size() - 1) && (control452 == 0))
                                                        {
                                                            System.out.println("Essa publicação não faz parte deste projeto.");
                                                        }
                                                    }
                                                    control45 = 1;
                                                }
                                                else if((s == Publicacoes.size() - 1) && (control45 == 0))
                                                {
                                                    System.out.println("Publicacao não encontrada, tente novamente.");
                                                }
                                            }
                                        }
                                    }
                                    if(resp2.equals("participantes"))
                                    {
                                        int resp32, e, r, t, u, control461, control462;
                                        control461 = control462 = 0;
                                        System.out.print("Você deseja adicionar ou remover uma participante?\nAdicionar: Digite 1\nRemover: Digite 2\nResp: ");
                                        resp32 = input.nextInt();
                                        if(resp32 == 1)
                                        {
                                            lixo = input.nextLine();
                                            String nome;
                                            System.out.println("Colaboradores existentes:");
                                            for(w = 0; w < Colaboradores.size(); w++)
                                            {
                                                System.out.println("-" + Colaboradores.get(w).getNome());
                                            }
                                            System.out.println("Digite o nome do colaborador que deseja adicionar: ");
                                            nome = input.nextLine();
                                            for(e = 0; e < Colaboradores.size(); e++)
                                            {
                                                if(Colaboradores.get(e).getNome().equals(nome))
                                                {
                                                    for(r = 0; r < Projetos.get(d).getParticipantes().size(); r++)
                                                    {
                                                        if(Projetos.get(d).getParticipantes().get(r).equals(nome))
                                                        {
                                                            System.out.println("O colaborador já faz parte do projeto");
                                                            control462 = 1;
                                                        }
                                                    }
                                                    if(control462 == 0)
                                                    {
                                                        int cont_aux = 0;
                                                        String proj;
                                                        if(Colaboradores.get(e).getTipo_colaborador().equals("aluno de graduacao"))
                                                        { 
                                                            for(t = 0; t < Colaboradores.get(e).getProjetos().size(); t++)
                                                            {
                                                                proj = Colaboradores.get(e).getProjetos().get(t);
                                                                for(u = 0; u < Projetos.size(); u++)
                                                                {
                                                                    if(proj == Projetos.get(u).getTitulo())
                                                                    {
                                                                        if(Projetos.get(u).getStatus().equals("em andamento"))
                                                                        {
                                                                            cont_aux++;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            if((Projetos.get(d).getStatus().equals("em andamento")) && (cont_aux >=2))
                                                            {
                                                                System.out.println("O colaborador é um aluno de graduação, e ja está em dois projetos em andamento");
                                                            }
                                                            if((Projetos.get(d).getStatus().equals("em andamento")) && (cont_aux < 2))
                                                            {
                                                                Projetos.get(d).getParticipantes().add(nome);
                                                                Colaboradores.get(e).getProjetos().add(Projetos.get(d).getTitulo());
                                                            }
                                                            else
                                                            {
                                                                Projetos.get(d).getParticipantes().add(nome);
                                                                Colaboradores.get(e).getProjetos().add(Projetos.get(d).getTitulo());
                                                            }
                                                        }
                                                        Projetos.get(d).getParticipantes().add(nome);
                                                        Colaboradores.get(e).getProjetos().add(Projetos.get(d).getTitulo());
                                                        if(Colaboradores.get(e).getTipo_colaborador().equals("professor"))
                                                        {
                                                            Colaboradores.get(e).getOrientacoes().add(Projetos.get(d).getTitulo());
                                                        }
                                                    }
                                                    control461 = 1;
                                                }
                                                else if((e == Colaboradores.size() - 1) && (control461 == 0))
                                                {
                                                    System.out.println("Colaborador não existe ou foi digitado incorretamente");
                                                }
                                            }
                                        }
                                        if(resp32 == 2)
                                        {
                                            lixo = input.nextLine();
                                            control462 = control461 = 0;
                                            String nome;
                                            System.out.println("Participantes existentes:");
                                            for(w = 0; w < Projetos.get(d).getParticipantes().size(); w++)
                                            {
                                                System.out.println("-" + Projetos.get(d).getParticipantes().get(w));
                                            }
                                            System.out.println("Digite o nome do colaborador que deseja remover: ");
                                            nome = input.nextLine();
                                            for(e = 0; e < Colaboradores.size(); e++)
                                            {
                                                if(Colaboradores.get(e).getNome().equals(nome))
                                                {
                                                    for(r = 0; r < Projetos.get(d).getParticipantes().size(); r++)
                                                    {
                                                        if(Projetos.get(d).getParticipantes().get(r).equals(nome))
                                                        {
                                                            Projetos.get(d).getParticipantes().remove(r);
                                                            for(u = 0; u < Colaboradores.get(e).getProjetos().size(); u++)
                                                            {
                                                                if(Colaboradores.get(e).getProjetos().get(u).equals(Projetos.get(d).getTitulo()))
                                                                {
                                                                    Colaboradores.get(e).getProjetos().remove(u);
                                                                    System.out.println("Removido com sucesso.");
                                                                }
                                                            }
                                                            control462 = 1;
                                                        }
                                                        else if((r == Projetos.get(d).getParticipantes().size() - 1) && (control462 == 0)) 
                                                        {
                                                            System.out.println("O colaborador não pertence a este projeto");
                                                        }
                                                    }
                                                    control461 = 1;
                                                }
                                                else if((e == Colaboradores.size() - 1) && (control461 == 0))
                                                {
                                                    System.out.println("Colaborador não existe ou foi digitado incorretamente");
                                                }
                                            }
                                        }
                                    }
                                    control43 = 1;
                                }
                                else if((d == Projetos.size() - 1) && (control43 == 0))
                                {
                                    System.out.println("Projeto não existe ou foi digitado incorretamente");
                                }
                            }
                        }
                    }
                }
                if(opcao == 5)
                {
                   lixo = input.nextLine();
                   int w, t, r, q, f, control5 = 0;
                   Projeto aux;
                   Publicacao aux2;
                   String nome;
                   System.out.println("Colaboradores existentes:");
                   for(w = 0; w < Colaboradores.size(); w++)
                   {
                       System.out.println("-" + Colaboradores.get(w).getNome());
                   }
                   System.out.println("Digite o nome do colaborador que você deseja ver os dados:");
                   nome = input.nextLine();
                   System.out.println();
                   for(w = 0; w < Colaboradores.size(); w++)
                   {
                        if(Colaboradores.get(w).getNome().equals(nome))
                        {
                            java.util.ArrayList<Projeto> Projetosprint = new java.util.ArrayList<Projeto>();
                            java.util.ArrayList<Publicacao> Publicacoesprint = new java.util.ArrayList<Publicacao>();
                            System.out.println("Nome: " + Colaboradores.get(w).getNome());
                            System.out.println("Email: " + Colaboradores.get(w).getEmail());
                            System.out.println("Projetos: " + Colaboradores.get(w).getProjetos());
                            for(t = 0; t < Colaboradores.get(w).getProjetos().size(); t++)
                            {
                                for(r= 0; r < Projetos.size(); r++)
                                {
                                    if(Colaboradores.get(w).getProjetos().get(t).equals(Projetos.get(r).getTitulo()))
                                    {
                                        if(Projetos.get(r).getStatus().equals("em andamento"))
                                        {
                                            Projetosprint.add(Projetos.get(r));
                                        }
                                    }
                                }
                            }
                            for(q = 0; q < Projetosprint.size(); q++)
                            {
                                for(f = q + 1; f < Projetosprint.size(); f++)
                                {
                                    if(Projetosprint.get(f).getAno_final() > Projetosprint.get(q).getAno_final())
                                    {
                                        aux = Projetosprint.get(f);
                                        Projetosprint.set(f, Projetosprint.get(q));
                                        Projetosprint.set(q, aux);
                                    }
                                }
                            }
                            for(q = 0; q < Projetosprint.size(); q++)
                            {
                                for(f = q + 1; f < Projetosprint.size(); f++)
                                {
                                    if(Projetosprint.get(f).getAno_final() >= Projetosprint.get(q).getAno_final())
                                    {
                                        if(Projetosprint.get(f).getMes_final() > Projetosprint.get(q).getMes_final())
                                        {
                                            aux = Projetosprint.get(f);
                                            Projetosprint.set(f, Projetosprint.get(q));
                                            Projetosprint.set(q, aux);
                                        }
                                    }
                                }
                            }
                            for(q = 0; q < Projetosprint.size(); q++)
                            {
                                for(f = q + 1; f < Projetosprint.size(); f++)
                                {
                                    if(Projetosprint.get(f).getAno_final() >= Projetosprint.get(q).getAno_final())
                                    {
                                        if(Projetosprint.get(f).getMes_final() >= Projetosprint.get(q).getMes_final())
                                        {
                                            if(Projetosprint.get(f).getDia_final() > Projetosprint.get(q).getDia_final())
                                            {
                                                aux = Projetosprint.get(f);
                                                Projetosprint.set(f, Projetosprint.get(q));
                                                Projetosprint.set(q, aux);
                                            }
                                        }
                                    }
                                }
                            }

                            System.out.println("Projetos em andamento: ");
                            for(t = 0; t < Projetosprint.size(); t++)
                            {
                                System.out.println(Projetosprint.get(t).getTitulo() + " - " + Projetosprint.get(t).getDia_final() + "/" + Projetosprint.get(t).getMes_final() + "/" + Projetosprint.get(t).getAno_final());
                            }

                            for(t = 0; t < Colaboradores.get(w).getPublicacoes().size(); t++)
                            {
                                for(r= 0; r < Publicacoes.size(); r++)
                                {
                                    if(Colaboradores.get(w).getPublicacoes().get(t).equals(Publicacoes.get(r).getTitulo()))
                                    {
                                        Publicacoesprint.add(Publicacoes.get(r));
                                    }
                                }
                            }
                            for(q = 0; q < Publicacoesprint.size(); q++)
                            {
                                for(f = q + 1; f < Publicacoesprint.size(); f++)
                                {
                                    if(Publicacoesprint.get(f).getAno_publicacao() > Publicacoesprint.get(q).getAno_publicacao())
                                    {
                                        aux2 = Publicacoesprint.get(f);
                                        Publicacoesprint.set(f, Publicacoesprint.get(q));
                                        Publicacoesprint.set(q, aux2);
                                    }
                                }
                            }

                            System.out.println("Produção academica: ");
                            for(t = 0; t < Publicacoesprint.size(); t++)
                            {
                                System.out.println(Publicacoesprint.get(t).getTitulo() + " - " + Publicacoesprint.get(t).getAno_publicacao());
                            }

                            control5 = 1;
                        }
                        else if((w == Colaboradores.size() - 1) && (control5 == 0))
                        {
                            System.out.println("Colaborador " + nome + ", não emcontrado, tente novamente.");
                        }
                   }
                }
                if(opcao == 6)
                {
                   lixo = input.nextLine();
                   int w, t, r, q, f, control6 = 0;
                   Projeto aux;
                   Publicacao aux2;
                   String nome;
                   System.out.println("Projetos existentes:");
                   for(w = 0; w < Projetos.size(); w++)
                   {
                       System.out.println("-" + Projetos.get(w).getTitulo());
                   }
                   System.out.println("Digite o nome do projeto que você deseja ver os dados:");
                   nome = input.nextLine();
                   System.out.println();
                   for(w = 0; w < Projetos.size(); w++)
                   {
                       if(Projetos.get(w).getTitulo().equals(nome))
                       {
                           java.util.ArrayList<Publicacao> Publicacoesprint = new java.util.ArrayList<Publicacao>();
                           System.out.println("Nome: " + Projetos.get(w).getTitulo());
                           System.out.println("Dia de inicio: " + Projetos.get(w).getDia_inicio());
                           System.out.println("Mes de inicio: " + Projetos.get(w).getMes_inicio());
                           System.out.println("Ano de inicio: " + Projetos.get(w).getAno_inicio());
                           System.out.println("Dia Finsl: " + Projetos.get(w).getDia_final());
                           System.out.println("Mes final: " + Projetos.get(w).getMes_final());
                           System.out.println("Ano Final: " + Projetos.get(w).getAno_final());
                           System.out.println("Agencia Financiadora: " + Projetos.get(w).getAg_financiadora());
                           System.out.println("Valor financiado: " + Projetos.get(w).getValor_financiado());
                           System.out.println("Objetivo: " + Projetos.get(w).getObjetivo());
                           System.out.println("Descricao: " + Projetos.get(w).getDescricao());
                           System.out.println("Status: " + Projetos.get(w).getStatus());
                           System.out.println("Integrantes: " + Projetos.get(w).getParticipantes());



                           for(t = 0; t < Projetos.get(w).getPublicacoes().size(); t++)
                            {
                                for(r= 0; r < Publicacoes.size(); r++)
                                {
                                    if(Projetos.get(w).getPublicacoes().get(t).equals(Publicacoes.get(r).getTitulo()))
                                    {
                                        Publicacoesprint.add(Publicacoes.get(r));
                                    }
                                }
                            }
                            for(q = 0; q < Publicacoesprint.size(); q++)
                            {
                                for(f = q + 1; f < Publicacoesprint.size(); f++)
                                {
                                    if(Publicacoesprint.get(f).getAno_publicacao() > Publicacoesprint.get(q).getAno_publicacao())
                                    {
                                        aux2 = Publicacoesprint.get(f);
                                        Publicacoesprint.set(f, Publicacoesprint.get(q));
                                        Publicacoesprint.set(q, aux2);
                                    }
                                }
                            }

                            System.out.println("Produção academica: ");
                            for(t = 0; t < Publicacoesprint.size(); t++)
                            {
                                System.out.println(Publicacoesprint.get(t).getTitulo() + " - " + Publicacoesprint.get(t).getAno_publicacao());
                            }
                            control6 = 1;
                       }
                       else if((w == Projetos.size() - 1) && (control6 == 0))
                       {
                           System.out.println("Projeto não existe ou digitado incorretamente, tente novamente");
                       }
                   }
                }
                if(opcao == 7)
                {
                    int r, cont = 0;
                    System.out.println("Relatório de Produção Acadêmica do Laboratório");
                    System.out.println("Número de colaboradores: " + Colaboradores.size());
                    for(r = 0; r < Projetos.size(); r++)
                    {
                        if(Projetos.get(r).getStatus().equals("em elaboracao"))
                        {    
                            cont++;
                        }
                    }
                    System.out.println("Número de projetos em elaboração: " + cont);
                    cont = 0;
                    for(r = 0; r < Projetos.size(); r++)
                    {
                        if(Projetos.get(r).getStatus().equals("em andamento"))
                        {    
                            cont++;
                        }
                    }
                    System.out.println("Número de projetos em andamento: " + cont);
                    cont = 0;
                    for(r = 0; r < Projetos.size(); r++)
                    {
                        if(Projetos.get(r).getStatus().equals("concluido"))
                        {    
                            cont++;
                        }
                    }
                    System.out.println("Número de projetos concluidos: " + cont);
                    cont = 0;
                    System.out.println("Número Total de projetos: " + Projetos.size());
                    System.out.println("Número de produção acadêmica por tipo de produção:\nPublicações: " + Publicacoes.size());
                    System.out.println();
                }
            }
            else
            {
                System.out.println("Nenhum colaborador foi cadastrado.");
            }
            System.out.println();
            System.out.println("1. Cadastrar Colaborador;");
            System.out.println("2. Lançar publicação;");
            System.out.println("3. Editar Publicações;");
            System.out.println("4. Criar ou editar projetos;");
            System.out.println("5. Consultar colaborador;");
            System.out.println("6. Consultar projeto;");
            System.out.println("7. Produção acadêmica do Laboratório;");
            //fim.
        }
    }
}
