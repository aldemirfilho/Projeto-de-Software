package Folhacod;

import java.util.ArrayList;

public class Agenda {
    int semanalmente;
    int dia_semana;
    
    int quinzenal;
    int dia_semana15;
    
    int mensal;
    int dia_mes;

    public int getDia_semana() {
        return dia_semana;
    }

    public void setDia_semana(int dia_semana) {
        this.dia_semana = dia_semana;
    }

    public int getDia_semana15() {
        return dia_semana15;
    }

    public void setDia_semana15(int dia_semana15) {
        this.dia_semana15 = dia_semana15;
    }

    public int getDia_mes() {
        return dia_mes;
    }

    public void setDia_mes(int dia_mes) {
        this.dia_mes = dia_mes;
    }

    public int getSemanalmente() {
        return semanalmente;
    }

    public void setSemanalmente(int semanalmente) {
        this.semanalmente = semanalmente;
    }

    public int getQuinzenal() {
        return quinzenal;
    }

    public void setQuinzenal(int quinzenal) {
        this.quinzenal = quinzenal;
    }

    public int getMensal() {
        return mensal;
    }

    public void setMensal(int mensal) {
        this.mensal = mensal;
    }
}

