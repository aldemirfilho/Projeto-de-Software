package Folhacod;

public class PagamentoAssalariado {
    int dia_do_mes;
    int mes;

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }
    float mensal_final;

    public float getMensal_final() {
        return mensal_final;
    }

    public void setMensal_final(float mensal_final) {
        this.mensal_final = mensal_final;
    }

    public int getDia_do_mes() {
        return dia_do_mes;
    }

    public void setDia_do_mes(int dia_do_mes) {
        this.dia_do_mes = dia_do_mes;
    }
}
