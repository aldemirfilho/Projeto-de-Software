package Folhacod;

public class Empregado 
{
   private String name;
   private String endereco;
   private String tipo;
   private float valor;
   private int id;
   private Ponto ponto;
   private Vendas valor_venda;
   private float porcentagem;
   private String metodo_pagamento;
   private Sindicato sind;
   private PagamentoHorista dia_semana; 
   private PagamentoComissionado dia_quinzena_semana;
   private PagamentoAssalariado dia_mes;
   private int freq_pagamento;
   private int dia_semana_1;
   private int dia_semana15;
   private int dia_mes_1;
   private String acao;
   
   /*
   public Empregado(Empregado copia) {
       this.name = copia.name;
   }
   */
   
    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    public int getDia_semana_1() {
        return dia_semana_1;
    }

    public void setDia_semana_1(int dia_semana_1) {
        this.dia_semana_1 = dia_semana_1;
    }

    public int getDia_semana15() {
        return dia_semana15;
    }

    public void setDia_semana15(int dia_semana15) {
        this.dia_semana15 = dia_semana15;
    }

    public int getDia_mes_1() {
        return dia_mes_1;
    }

    public void setDia_mes_1(int dia_mes_1) {
        this.dia_mes_1 = dia_mes_1;
    }

    public int getFreq_pagamento() {
        return freq_pagamento;
    }

    public void setFreq_pagamento(int freq_pagamento) {
        this.freq_pagamento = freq_pagamento;
    }
 
    public PagamentoHorista getDia_semana() {
        return dia_semana;
    }

    public void setDia_semana(PagamentoHorista dia_semana) {
        this.dia_semana = dia_semana;
    }
    
    public PagamentoComissionado getDia_quinzena_semana() {
        return dia_quinzena_semana;
    }

    public void setDia_quinzena_semana(PagamentoComissionado dia_quinzena_semana) {
        this.dia_quinzena_semana = dia_quinzena_semana;
    }

    public PagamentoAssalariado getDia_mes() {
        return dia_mes;
    }

    public void setDia_mes(PagamentoAssalariado dia_mes) {
        this.dia_mes = dia_mes;
    }

    public Sindicato getSind() {
        return sind;
    }

    public void setSind(Sindicato sind) {
        this.sind = sind;
    }
           
    public String getMetodo_pagamento() {
        return metodo_pagamento;
    }

    public void setMetodo_pagamento(String metodo_pagamento) {
        this.metodo_pagamento = metodo_pagamento;
    }

    public float getPorcentagem() {
        return porcentagem;
    }

    public void setPorcentagem(float porcentagem) {
        this.porcentagem = porcentagem;
    }
 
    public Vendas getValor_venda() {
        return valor_venda;
    }

    public void setValor_venda(Vendas valor_venda) {
        this.valor_venda = valor_venda;
    }
    public Ponto getPonto() {
        return ponto;
    }
    
    public void setPonto(Ponto ponto) {
        this.ponto = ponto;
    }
   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }   
}
