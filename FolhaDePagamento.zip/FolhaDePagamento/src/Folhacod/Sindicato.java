package Folhacod;

public class Sindicato {
   private String part_sindicato;
   private int id_sindicato;
   private float porcentagem_sind;
   private float porcentagem_sind_adicional;

    public int getId_sindicato() {
        return id_sindicato;
    }

    public void setId_sindicato(int id_sindicato) {
        this.id_sindicato = id_sindicato;
    }
    
   public String getPart_sindicato() {
        return part_sindicato;
    }

    public void setPart_sindicato(String part_sindicato) {
        this.part_sindicato = part_sindicato;
    }

    public float getPorcentagem_sind() {
        return porcentagem_sind;
    }

    public void setPorcentagem_sind(float porcentagem_sind) {
        this.porcentagem_sind = porcentagem_sind;
    }

    public float getPorcentagem_sind_adicional() {
        return porcentagem_sind_adicional;
    }

    public void setPorcentagem_sind_adicional(float porcentagem_sind_adicional) {
        this.porcentagem_sind_adicional = porcentagem_sind_adicional;
    }
}
