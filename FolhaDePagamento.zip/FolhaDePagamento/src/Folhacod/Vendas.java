package Folhacod;

public class Vendas 
{
    private float valor_vendas;
    private String data;
    
    public float getValor_vendas() {
        return valor_vendas;
    }

    public void setValor_vendas(float valor_vendas) {
        this.valor_vendas = valor_vendas;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
