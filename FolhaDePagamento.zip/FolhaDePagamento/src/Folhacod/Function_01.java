package Folhacod;

import java.util.Calendar;
import static java.util.Calendar.DAY_OF_WEEK;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;

public class Function_01 
{
	public static void main(String[] args)
        {
		for(int i = 0; i < 0; ++i) 
		{
			System.out.println();
		}
		
		 Scanner input = new Scanner(System.in);
                 
		System.out.println();
		System.out.print("              Bem vindo ao sistema de folha de pagamento!!!\n");
                System.out.println();
		System.out.print("Digite a opção de qual função deseja execultar...\n");
                System.out.println();
		System.out.print("1 . Adição de um empregado\n");
		System.out.print("2 . Remoção de um empregado\n");
		System.out.print("3 . Lançar um Cartão de Ponto\n");
		System.out.print("4 . Lançar um Resultado Venda\n");
		System.out.print("5 . Lançar uma taxa de serviço\n");
		System.out.print("6 . Alterar detalhes de um empregado\n");
		System.out.print("7 . Rodar a folha de pagamento para hoje\n");
		System.out.print("8 . Undo/redo\n");
		System.out.print("9 . Agenda de Pagamento\n");
		System.out.print("10 . Criação de Novas Agendas de Pagamento\n");
                System.out.println();
		System.out.print("Opção: ");
		
                int opcao = 0;
                int cont = 0;
		int id;
		
                java.util.ArrayList<Empregado> Empregados = new java.util.ArrayList<Empregado>();
                int controle = 1;
                
                float pagamento, desconto = 0;
                int dia, mes, ano, dia_semana;
                Calendar current = Calendar.getInstance();
                dia = current.get(Calendar.DATE);
                mes = current.get(Calendar.MONTH) + 1;
                ano = current.get(Calendar.YEAR);
                dia_semana = current.get(DAY_OF_WEEK);
                /*
                dia = 30;
                mes = 11;
                dia_semana = 6;
                */
                
                Agenda agenda = new Agenda();
                agenda.setMensal(1);
                agenda.setQuinzenal(2);
                agenda.setSemanalmente(3);
                
                agenda.setDia_semana(6);
                agenda.setDia_semana15(6);
                agenda.setDia_mes(50);
                
                Stack<Empregado> undo = new Stack<Empregado>();
                Stack<Empregado> redo = new Stack<Empregado>();
                
                while(opcao != 11)
                {
                    opcao = input.nextInt();

                    String lixo = new String();
                    lixo = input.nextLine();

                    if(opcao == 1)
                    {
                            cont++;

                            System.out.println();

                            Empregado funcionario1 = new Empregado( );

                            System.out.print("->Digite o nome do empregado: ");
                            funcionario1.setName(input.nextLine()); 
                            System.out.print("\n");

                            System.out.print("->Digite o endereco do empregado: ");
                            funcionario1.setEndereco(input.nextLine());
                            System.out.print("\n");

                            System.out.print("->Digite o tipo de recebimento do empregado: \n (assalariado, horista, comissionado)\n");
                            funcionario1.setTipo(input.nextLine());
                            System.out.print("\n");
                            
                            if(funcionario1.getTipo().equals("assalariado"))
                            {
                                System.out.print("->Digite o valor recebido do empregado: ");
                                funcionario1.setValor(input.nextInt());
                                funcionario1.setFreq_pagamento(agenda.getMensal());
                                funcionario1.setDia_mes_1(agenda.getDia_mes());
                                System.out.print("\n");
                            }
                            
                            else if(funcionario1.getTipo().equals("horista"))
                            {
                                System.out.print("->Digite o valor recebido por hora pelo o empregado: ");
                                funcionario1.setValor(input.nextInt());
                                funcionario1.setFreq_pagamento(agenda.getSemanalmente());
                                funcionario1.setDia_semana_1(agenda.getDia_semana());
                                System.out.print("\n");
                            }
                            
                            else if(funcionario1.getTipo().equals("comissionado"))
                            {
                                System.out.println("->Digite 0, para que o numero de vendas de tal funcionario inicie-se zerado: ");
                                int num_vendas;
                                num_vendas = input.nextInt();
                                    
                                Vendas valor = new Vendas();
                                valor.setValor_vendas(num_vendas);
                                    
                                funcionario1.setValor_venda(valor);
                                
                                System.out.println("->Digite a porcentagem que este funcionário ganhará em cima de cada venda: ");
                                int porcentagem;
                                porcentagem = input.nextInt();
                                
                                funcionario1.setPorcentagem(porcentagem);
                                
                                System.out.print("->Digite o valor recebido por quinzena pelo o empregado: ");
                                funcionario1.setValor(input.nextInt());
                                funcionario1.setFreq_pagamento(agenda.getQuinzenal());
                                funcionario1.setDia_semana15(agenda.getDia_semana15());
                                System.out.print("\n");
                            }
                            
                            String lixo2 = new String();
                            lixo2 = input.nextLine();
                            
                            System.out.print("->Digite o método de pagamento de preferencia do empregado: \n(Cheque pelos correios, Cheque em mãos, Deposito em conta bancária)\n");
                            funcionario1.setMetodo_pagamento(input.nextLine());
                            System.out.print("\n");
                            
                            System.out.println("Serão definidos como padrão os dias de pagamento para os funcionários, seguindo as seguites regras:\n -Horistas: Todas as Sextas-Feiras, acrescido de horas extras caso exitir.\n -Assalariados: Todos os ultimos dias uteis do mês corrente.\n -Comissionados: A cada duas semanas, nas Sextas-Feiras, acrescidos das comissões de vendas, casos exista.\n");
                            System.out.println("Caso queira editar os dias, podem ser alterados na opção 10\n");
                            
                            if(funcionario1.getTipo().equals("horista"))
                            {
                                PagamentoHorista pagamentoH = new PagamentoHorista();
                                pagamentoH.setDia_da_semana(6);
                                pagamentoH.setHoras_trabalhadas(0);
                                pagamentoH.setExtras(0);
                                funcionario1.setDia_semana(pagamentoH);
                            }
                            
                            if(funcionario1.getTipo().equals("assalariado"))
                            {
                                PagamentoAssalariado pagamentoA = new PagamentoAssalariado();
                                funcionario1.setDia_mes(pagamentoA);
                            }
                            
                            if(funcionario1.getTipo().equals("comissionado"))
                            {
                                PagamentoComissionado pagamentoC = new PagamentoComissionado();
                                pagamentoC.setDia_da_semana(6);
                                pagamentoC.setData_mes(0);
                                funcionario1.setDia_quinzena_semana(pagamentoC);
                            }
                            
                            System.out.print("->O novo funcionário faz parte de um sindicato?\n Digite sim ou nao: ");
                            
                            Sindicato sindicato1 = new Sindicato();
                            
                            sindicato1.setPart_sindicato(input.nextLine());
                            System.out.print("\n");
                            
                            if(sindicato1.getPart_sindicato().equals("sim"))
                            {
                                System.out.println("->Digite a porcentagem da taxa básica descontada do salario dedicada ao sindicato: ");
                                sindicato1.setPorcentagem_sind(input.nextInt());
                                sindicato1.setPorcentagem_sind_adicional(0);
                                int id_sindicato = cont + 999;
                                sindicato1.setId_sindicato(id_sindicato);
                                System.out.print("\n");
                                System.out.println("->O id do sindicato do seu empregado é: " + id_sindicato);
                                System.out.print("\n");
                            }
                            
                            funcionario1.setSind(sindicato1);
                            
                            System.out.println("->O id empresarial do seu empregado é: " + cont);
                            funcionario1.setId(cont);
                            
                            System.out.print("\n");

                            Empregados.add(funcionario1);
                            
                            funcionario1.setAcao("add");
                            undo.push(funcionario1);
                            System.out.println("---------------------------------------------");
                    }
                    if(opcao == 2)
                    {
                        System.out.println("->Digite o id do funcionario a ser removido: ");
                        int id_removed = input.nextInt();
                        int i;
                        Empregado funcionario2 = new Empregado( );
                        for(i = 0; i < Empregados.size(); i++)
                        {
                               funcionario2 = Empregados.get(i);
                               //System.out.println(funcionario.getId());
                               if(funcionario2.getId() == id_removed)
                               {
                                   funcionario2.setAcao("removed");
                                   undo.push(funcionario2);
                                   
                                   Empregados.remove(funcionario2);
                                   System.out.println("Funcionário removido com sucesso!!!\n");
                               }
                               else  if(i == Empregados.size() - 1)
                               {
                                   System.out.println("Tal id não pertence a nenhum funcionario registrado.\n");
                               }
                        }
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 3)
                    {
                        System.out.println("->Insira seu id, para marcar presença: ");
                        int meu_id = input.nextInt();
                        int j, momento;
                        Empregado funcionario3 = new Empregado();
                        Ponto p = new Ponto();
                        PagamentoHorista pagamentoH = new PagamentoHorista();
                            
                        for(j = 0; j < Empregados.size(); j++)
                        {
                            funcionario3 = Empregados.get(j);
                            if(funcionario3.getId() == meu_id)
                            {
                                funcionario3.setAcao("ponto");
                                undo.push(funcionario3);
                                if(funcionario3.getTipo().equals("horista"))
                                {
                                    pagamentoH = funcionario3.getDia_semana();
                                    System.out.println("->Para marcar o ponto de entrada digite 1 ou 2 para marcar o ponto de saida: ");
                                    momento = input.nextInt();
                                    if(momento == 1)
                                    {
                                        System.out.println("->Insira a hora de chegada: \n(Inseriondo um numero de 7 a 23)\n");
                                        p.setHora_entrada(input.nextInt());
                                        funcionario3.setPonto(p);
                                    }
                                    else
                                    {
                                        p = funcionario3.getPonto();
                                        System.out.println("->Insira a hora de saida: \n(Inseriondo um numero de 7 a 23)\n");
                                        p.setHora_saida(input.nextInt());
                                        
                                        int total_dia = p.getHora_saida() - p.getHora_entrada();
                                        int total_dia_extras = total_dia;
                                        total_dia = total_dia - (total_dia - 8);
                                        pagamentoH.setHoras_trabalhadas(total_dia + pagamentoH.getHoras_trabalhadas());
                                        if(total_dia_extras > 8)
                                        {
                                            int extra;
                                            extra = total_dia_extras - 8;
                                            pagamentoH.setExtras(extra + pagamentoH.getExtras());
                                        }
                                    }
                                    funcionario3.setDia_semana(pagamentoH);
                                     System.out.println();
                                    System.out.println("Horas normais registradas: " + funcionario3.getDia_semana().getHoras_trabalhadas());
                                    System.out.println("HOras extras registradas: " + funcionario3.getDia_semana().getExtras());
                                    //funcionario.ponto.hora_entrada
                                }
                                else
                                {
                                    p.setPresenca(1);
                                }
                                funcionario3.setPonto(p);
                                //System.out.println("hora entrada" + funcionario3.getPonto().getHora_entrada());
                            }
                        }
                        System.out.println();
                        System.out.println("Presença registrada com sucesso!!!\n");
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 4)
                    {
                        float valor_venda;
                        int i, id_vendedor;
                        System.out.println("->Insira o id do funcionario, para registrar a venda: ");
                        id_vendedor = input.nextInt();
                        //checar se ele é comossionado
                        Empregado funcionario4 = new Empregado( );
                        for(i = 0; i < Empregados.size(); i++)
                        {
                            funcionario4 = Empregados.get(i);
                            if(funcionario4.getId() == id_vendedor)
                            {
                                funcionario4.setAcao("venda");
                                undo.push(funcionario4);
                                
                                if(funcionario4.getTipo().equals("comissionado"))
                                {
                                    System.out.println("->Digite a valor da venda: ");
                                    valor_venda = input.nextInt();
                                    valor_venda = valor_venda * (funcionario4.getPorcentagem())/100;
                                    
                                    if((funcionario4.getValor_venda().getValor_vendas()) == 0)
                                    {
                                        Vendas valor = new Vendas();
                                        valor.setValor_vendas(valor_venda);

                                        funcionario4.setValor_venda(valor);
                                    }
                                    else
                                    {
                                        valor_venda = valor_venda + (funcionario4.getValor_venda().getValor_vendas());
                                        
                                        Vendas valor = new Vendas();
                                        valor.setValor_vendas(valor_venda);

                                        funcionario4.setValor_venda(valor);
                                    }
                                    System.out.println();
                                   // System.out.println("vendas" + funcionario4.getValor_venda().getValor_vendas());
                                }
                                else
                                {
                                    System.out.println("Obs: Este id pertence a um funcionario não comissionado...\n");
                                }
                            }
                        }
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 5)
                    {   
                        int i, id_funcionario;
                        System.out.println("->Insira o id do funcionário, para registrar a taxa de serviço: ");
                        id_funcionario = input.nextInt();
                        //checar se ele é comossionado
                        Empregado funcionario5 = new Empregado( );
                        Sindicato sindicato5 = new Sindicato();
                        
                        for(i = 0; i < Empregados.size(); i++)
                        {
                            funcionario5 = Empregados.get(i);
                            if(funcionario5.getId() == id_funcionario)
                            {
                                funcionario5.setAcao("taxa");
                                undo.push(funcionario5);
                                
                                sindicato5 = funcionario5.getSind();
                                if(sindicato5.getPart_sindicato().equals("sim"))
                                {
                                    System.out.println("->Digite a porcentagem das taxas adicionais de serviços ligadas ao sidicato: ");
                                    sindicato5.setPorcentagem_sind_adicional(input.nextFloat());
                                    funcionario5.setSind(sindicato5);
                                    System.out.println();
                                }
                                else
                                {
                                    System.out.println("Obs: Tal funcionario não esta associado a um sindicato.\n");
                                }
                            }
                        }
                        //System.out.println(funcionario5.getSind().getPorcentagem_sind_adicional());
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 6)
                    {
                        int id_edit, edit, i;
                        System.out.println("->Digite o id do funcionario que deseja alterar: ");
                        id_edit = input.nextInt();
                        
                        System.out.println();
                        
                        Empregado funcionario6 = new Empregado( );
                        for(i = 0; i < Empregados.size(); i++)
                        {
                            funcionario6 = Empregados.get(i);
                            //System.out.println(funcionario.getId());
                            if(funcionario6.getId() == id_edit)
                            {
                                funcionario6.setAcao("edit");
                                undo.push(funcionario6);
                                
                                System.out.println("->Digite o numero de qual opção deseja alterar no cadastro do funcionário:\n1.Nome\n2.Endereço\n3.Tipo de Funcionário\n4.Método de pagamento\n5.Associação a sindicatos\n6.Identificação no sindicato\n7.Taxa sindical\nOpçaõ: ");
                                edit = input.nextInt();
                                
                                String lixo3 = new String();
                                lixo3 = input.nextLine();
                                
                                if(edit == 1)
                                {
                                    System.out.println("->Digite o novo nome do funcionário escolhido: ");
                                    funcionario6.setName(input.nextLine());
                                    System.out.print("\n");
                                }
                                else if(edit == 2)
                                {
                                    System.out.println("->Digite o novo endereço do funcinário escolhido: ");
                                    funcionario6.setEndereco(input.nextLine());
                                    System.out.print("\n");
                                }
                                else if(edit == 3)
                                {
                                    if(funcionario6.getTipo().equals("assalariado"))
                                    {
                                        System.out.println("->Digite o novo tipo de funcinário, do funcionário escolhido: ");
                                        funcionario6.setTipo(input.nextLine());
                                        if(funcionario6.getTipo().equals("horista"))
                                        {
                                            System.out.println("->Digite o salaraio por hora desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getSemanalmente());
                                            funcionario6.setDia_semana_1(agenda.getDia_semana());
                                        }
                                        else if(funcionario6.getTipo().equals("comissionado"))
                                        {
                                            System.out.println("->Digite o salaraio quinzenal desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getQuinzenal());
                                            funcionario6.setDia_semana15(agenda.getDia_semana15());
                                        }
                                        System.out.print("\n");
                                    }
                                    else if(funcionario6.getTipo().equals("horista"))
                                    {
                                        System.out.println("->Digite o novo tipo de funcinário, do funcionário escolhido: ");
                                        funcionario6.setTipo(input.nextLine());
                                        if(funcionario6.getTipo().equals("assalariado"))
                                        {
                                            System.out.println("->Digite o salaraio por mes desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getMensal());
                                            funcionario6.setDia_mes_1(agenda.getDia_mes());
                                        }
                                        else if(funcionario6.getTipo().equals("comissionado"))
                                        {
                                            System.out.println("->Digite o salaraio quinzenal desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getQuinzenal());
                                            funcionario6.setDia_semana15(agenda.getDia_semana15());
                                        }
                                        System.out.print("\n");
                                    }
                                    else if(funcionario6.getTipo().equals("comissionado"))
                                    {
                                        System.out.println("->Digite o novo tipo de funcinário, do funcionário escolhido: ");
                                        funcionario6.setTipo(input.nextLine());
                                        if(funcionario6.getTipo().equals("assalariado"))
                                        {
                                            System.out.println("->Digite o salaraio por mes desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getMensal());
                                            funcionario6.setDia_mes_1(agenda.getDia_mes());
                                        }
                                        else if(funcionario6.getTipo().equals("horista"))
                                        {
                                            System.out.println("->Digite o salaraio por hora desse empregado: ");
                                            funcionario6.setValor(input.nextInt());
                                            funcionario6.setFreq_pagamento(agenda.getSemanalmente());
                                            funcionario6.setDia_semana_1(agenda.getDia_semana());
                                        }
                                        System.out.print("\n");
                                    }
                                }
                                else if(edit == 4)
                                {
                                    System.out.println("->Digite o novo método de pagamento do funcionário escolhido: ");
                                    funcionario6.setTipo(input.nextLine());
                                    System.out.print("\n");
                                }
                                else if(edit == 5)
                                {
                                    Sindicato sindicato6_5 = new Sindicato();
                                    sindicato6_5 = funcionario6.getSind();
                                    
                                    System.out.println("->Digite o novo status do funcinário em relação a participação de um sindicato:\n Digite sim ou nao: ");
                                    sindicato6_5.setPart_sindicato(input.nextLine());
                                    
                                    funcionario6.setSind(sindicato6_5);
                                    
                                    System.out.print("\n");
                                }
                                else if(edit == 6)
                                {   
                                    int j, existe;
                                    existe = 1;
                                    Empregado funcionario6_6 = new Empregado();
                                    
                                    Sindicato sindicato6_6 = new Sindicato();
                                    sindicato6_6 = funcionario6.getSind();
                                  
                                    System.out.println("->Digite um novo id que represente o trabalhador no sindicato:\n (não insira id's pertencentes a outros funcionários)\n");
                                    sindicato6_6.setId_sindicato(input.nextInt());
                                   
                                    while(existe == 1)
                                    {
                                        for(j = 0; j < Empregados.size(); j++)
                                        {
                                            funcionario6_6 = Empregados.get(j);
                                            //System.out.println(funcionario.getId());
                                            if(funcionario6_6.getSind().getId_sindicato() == sindicato6_6.getId_sindicato())
                                            {
                                                System.out.println("Obs: Este id ja exite, tente outro...");
                                                sindicato6_6.setId_sindicato(input.nextInt());
                                            }
                                            else
                                            {
                                                existe = 0;
                                            }
                                        }
                                    }
                                    funcionario6.setSind(sindicato6_6);
                                }
                                else if(edit == 7)
                                {
                                    Sindicato sindicato6_7 = new Sindicato();
                                    sindicato6_7 = funcionario6.getSind();
                                    
                                    System.out.println("->Digite a nova taxa sindical básica do funcionário: ");
                                    sindicato6_7.setPorcentagem_sind(input.nextInt());
                                    
                                    funcionario6.setSind(sindicato6_7);
                                    
                                    System.out.print("\n");
                                }
                            }
                        }
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 7)
                    {
                        Empregado funcionario7 = new Empregado();
                        
                         System.out.println("DATA ATUAL " + dia + "/" + mes + "/" + ano + ".");
                        
                        int j;
                        
                        for(j = 0; j < Empregados.size(); j++)
                        {
                            funcionario7 = Empregados.get(j);
                            if(funcionario7.getFreq_pagamento() == 3)
                            {
                                funcionario7.setAcao("pag");
                                undo.push(funcionario7);
                                
                                if(funcionario7.getDia_semana_1() == dia_semana)
                                {
                                    int horas = funcionario7.getDia_semana().getHoras_trabalhadas();
                                    pagamento = (funcionario7.getValor() * funcionario7.getDia_semana().getHoras_trabalhadas()) + ((funcionario7.getValor() + (funcionario7.getValor()/2)) * funcionario7.getDia_semana().getExtras());
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        desconto = (funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind() / 100)) * funcionario7.getDia_semana().getHoras_trabalhadas();

                                        if(funcionario7.getSind().getPorcentagem_sind_adicional() != 0)
                                        {
                                            desconto = desconto + (funcionario7.getValor() * ((funcionario7.getSind().getPorcentagem_sind_adicional() / 100) * funcionario7.getDia_semana().getHoras_trabalhadas()));
                                        }
                                    }
                                    pagamento = pagamento - desconto;
                                    PagamentoHorista pagamentoH = new PagamentoHorista();
       
                                    pagamentoH.setDia_da_semana(dia);
                                    pagamentoH.setMes(mes);
                                    pagamentoH.setSemanal_final(pagamento);
                                    
                                    funcionario7.setDia_semana(pagamentoH);
                                    System.out.println();
                                    System.out.println("         FOLHA DE PAGAMENTO");
                                    System.out.println("Nome do funcionário: " + funcionario7.getName() + ".");
                                    System.out.println("Numero de Identificação: " + funcionario7.getId() + ".");
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        System.out.println("Numero de Identificação sindical: " + funcionario7.getSind().getId_sindicato()+ ".");
                                    }
                                    System.out.println("Tipo de recebimento: " + funcionario7.getTipo() + ".");
                                    System.out.println("Endereço: " + funcionario7.getEndereco() + ".");
                                    System.out.println("Horas extras: " + funcionario7.getDia_semana().getExtras() + ".");
                                    System.out.println("Horas normais: " + horas + ".");
                                    System.out.println("Data de pagamento: " + dia + "/" + mes + "/" + ano + ".");;
                                    System.out.println("Salário com os devidos descontos: " + funcionario7.getDia_semana().getSemanal_final() + ".");
                                    System.out.println("Forma de pagamento: " + funcionario7.getMetodo_pagamento() + ".");
                                    System.out.println("Jornada de trabalho: Das " + funcionario7.getPonto().getHora_entrada() + ":00h ás " + funcionario7.getPonto().getHora_saida() + ":00h.");
                                    System.out.println();
                                }
                            }
                            if(funcionario7.getFreq_pagamento() == 2)
                            {
                                if(funcionario7.getDia_semana15() == dia_semana)
                                {
                                    funcionario7.setAcao("pag");
                                    undo.push(funcionario7);
                                    
                                    pagamento = funcionario7.getValor() + funcionario7.getValor_venda().getValor_vendas();
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        desconto = funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind() / 100);

                                        if(funcionario7.getSind().getPorcentagem_sind_adicional() != 0)
                                        {
                                            desconto = desconto + (funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind_adicional() / 100));
                                        }
                                    }

                                    pagamento = pagamento - desconto;
                                    PagamentoComissionado pagamentoC = new PagamentoComissionado();
                                    
                                    if(controle == 2)
                                    {
                                        pagamentoC.setDia_da_semana(dia);
                                        pagamentoC.setData_mes(mes);
                                        pagamentoC.setQuinzena_final(pagamento);
                                        funcionario7.setDia_quinzena_semana(pagamentoC);
                                        
                                        controle = 1;
                                        
                                        System.out.println();
                                        System.out.println("         FOLHA DE PAGAMENTO");
                                        System.out.println("Nome do funcionário: " + funcionario7.getName() + ".");
                                        System.out.println("Numero de Identificação: " + funcionario7.getId() + ".");
                                        if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                        {
                                            System.out.println("Numero de Identificação: " + funcionario7.getSind().getId_sindicato() + ".");
                                        }
                                        System.out.println("Tipo de recebimento: " + funcionario7.getTipo() + ".");
                                        System.out.println("Endereço: " + funcionario7.getEndereco() + ".");
                                        System.out.println("Total arrecadado por comissão com as vendas: " + funcionario7.getValor_venda().getValor_vendas() + ".");
                                        System.out.println("Data de pagamento: " + dia + "/" + mes + "/" + ano + ".");
                                        System.out.println("Salário com os devidos descontos: " + funcionario7.getDia_quinzena_semana().getQuinzena_final()+ ".");
                                        System.out.println("Forma de pagamento: " + funcionario7.getMetodo_pagamento() + ".");
                                        System.out.println();
                                    }
                                    else
                                    {
                                        controle++;
                                    }
                                }
                            }
                            if(funcionario7.getFreq_pagamento() == 1)
                            {   
                                int primeiro_dia_mes_semanal = 0;
                                int diff = dia - dia_semana;
                                int resto_dias_atras = diff % 7;
                                if(resto_dias_atras == 0) //mes comecou num domingo
                                {
                                    primeiro_dia_mes_semanal = 1;
                                }
                                else if(resto_dias_atras == 1) //mes comecou num sabado
                                {
                                    primeiro_dia_mes_semanal = 7;
                                }
                                else if(resto_dias_atras == 2) //mes comecou numa sexta
                                {
                                    primeiro_dia_mes_semanal = 6;
                                }
                                else if(resto_dias_atras == 3) //mes comecou numa quinta
                                {
                                    primeiro_dia_mes_semanal = 5;
                                }
                                else if(resto_dias_atras == 4) //mes comecou numa quarta
                                {
                                    primeiro_dia_mes_semanal = 4;
                                }
                                else if(resto_dias_atras == 5) //mes comecou num terca
                                {
                                    primeiro_dia_mes_semanal = 3;
                                }
                                else if(resto_dias_atras == 6) //mes comecou numa segunda
                                {
                                    primeiro_dia_mes_semanal = 2;
                                }
                                //----------------------------------------------------------------------------------------------
                                if(funcionario7.getDia_mes_1() == 50)
                                {
                                    funcionario7.setAcao("pag");
                                    undo.push(funcionario7);
                                    
                                    int ultimo_dia, ultimo_dia_mes = 0;

                                    if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12)
                                    {
                                        int diff2; 
                                        diff2 = 31 - ((7 - primeiro_dia_mes_semanal) + 1);
                                        ultimo_dia = diff2 % 7;
                                    }
                                    else if(mes == 2)
                                    {
                                        int diff2; 
                                        diff2 = 28 - ((7 - primeiro_dia_mes_semanal) + 1);
                                        ultimo_dia = diff2 % 7;
                                    }
                                    else
                                    {
                                        int diff2;
                                        diff2 = 30 - ((7 - primeiro_dia_mes_semanal) + 1);
                                        ultimo_dia = diff2 % 7;
                                    }

                                    if(ultimo_dia != 7 && ultimo_dia != 1)
                                    { 
                                        if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12)
                                        {
                                            ultimo_dia_mes = 31;
                                        }
                                        else if(mes == 2)
                                        {
                                           ultimo_dia_mes = 28;
                                        }
                                        else
                                        {
                                            ultimo_dia_mes = 30;
                                        }
                                    }
                                    else
                                    {
                                        if((mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) && ultimo_dia == 7)
                                        {
                                            ultimo_dia_mes = 30;
                                        }
                                        else if((mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) && ultimo_dia == 1)
                                        {
                                            ultimo_dia_mes = 29;
                                        }
                                        else if((mes == 2) && ultimo_dia == 7)
                                        {
                                            ultimo_dia_mes = 27;
                                        }
                                        else if((mes == 2) && ultimo_dia == 1)
                                        {
                                            ultimo_dia_mes = 26;
                                        }
                                        else if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && ultimo_dia == 7)
                                        {
                                            ultimo_dia_mes = 29;
                                        }
                                        else if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && ultimo_dia == 1)
                                        {
                                            ultimo_dia_mes = 28;
                                        }
                                    }
                                    pagamento = funcionario7.getValor();
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        desconto = funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind() / 100);

                                        if(funcionario7.getSind().getPorcentagem_sind_adicional() != 0)
                                        {
                                            desconto = desconto + (funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind_adicional() / 100));
                                        }
                                    }

                                    pagamento = pagamento - desconto;
                                    PagamentoAssalariado pagamentoA = new PagamentoAssalariado();

                                    if(dia == ultimo_dia_mes)
                                    {
                                        pagamentoA.setDia_do_mes(dia);
                                        pagamentoA.setMensal_final(pagamento);

                                        funcionario7.setDia_mes(pagamentoA);
                                        System.out.println();
                                        System.out.println("         FOLHA DE PAGAMENTO");
                                        System.out.println("Nome do funcionário: " + funcionario7.getName() + ".");
                                        System.out.println("Numero de Identificação: " + funcionario7.getId() + ".");
                                        if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                        {
                                            System.out.println("Numero de Identificação: " + funcionario7.getSind().getId_sindicato() + ".");
                                        }
                                        System.out.println("Tipo de recebimento: " + funcionario7.getTipo() + ".");
                                        System.out.println("Endereço: " + funcionario7.getEndereco() + ".");
                                        System.out.println("Data de pagamento: " + dia + "/" + mes + "/" + ano + ".");
                                        System.out.println("Salário com os devidos descontos: " + funcionario7.getDia_mes().getMensal_final() + ".");
                                        System.out.println("Forma de pagamento: " + funcionario7.getMetodo_pagamento() + ".");
                                        System.out.println();
                                    }
                                }
                                else if(funcionario7.getDia_mes_1() == dia)
                                {
                                    funcionario7.setAcao("pag");
                                    undo.push(funcionario7);
                                    
                                    pagamento = funcionario7.getValor();
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        desconto = funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind() / 100);

                                        if(funcionario7.getSind().getPorcentagem_sind_adicional() != 0)
                                        {
                                            desconto = desconto + (funcionario7.getValor() * (funcionario7.getSind().getPorcentagem_sind_adicional() / 100));
                                        }
                                    }

                                    pagamento = pagamento - desconto;
                                    PagamentoAssalariado pagamentoA = new PagamentoAssalariado();
                                    
                                    pagamentoA.setDia_do_mes(dia);
                                    pagamentoA.setMensal_final(pagamento);

                                    funcionario7.setDia_mes(pagamentoA);
                                    System.out.println();
                                    System.out.println("         FOLHA DE PAGAMENTO");
                                    System.out.println("Nome do funcionário: " + funcionario7.getName() + ".");
                                    System.out.println("Numero de Identificação: " + funcionario7.getId() + ".");
                                    if(funcionario7.getSind().getPart_sindicato().equals("sim"))
                                    {
                                        System.out.println("Numero de Identificação: " + funcionario7.getSind().getId_sindicato() + ".");
                                    }
                                    System.out.println("Tipo de recebimento: " + funcionario7.getTipo() + ".");
                                    System.out.println("Endereço: " + funcionario7.getEndereco() + ".");
                                    System.out.println("Data de pagamento: " + dia + "/" + mes + "/" + ano + ".");
                                    System.out.println("Salário com os devidos descontos: " + funcionario7.getDia_mes().getMensal_final() + ".");
                                    System.out.println("Forma de pagamento: " + funcionario7.getMetodo_pagamento() + ".");
                                    System.out.println();
                                }
                            }
                        }
                        if((mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12))
                        {
                            if(mes == 12 && dia == 31)
                            {
                                mes = 1;
                                dia = 1;
                                ano++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                            else if (dia != 31)
                            {
                                dia++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                            else if(dia == 31)
                            {
                                dia = 1;
                                mes++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                        }
                        else if((mes == 4 || mes == 6 || mes == 9 || mes == 11))
                        {
                            if (dia != 30)
                            {
                                dia++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                            else if(dia == 30)
                            {
                                dia = 1;
                                mes++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                        }
                        else if(mes == 2)
                        {
                            if (dia != 28)
                            {
                                dia++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                            else if (dia == 28)
                            {
                                dia = 1;
                                mes++;
                                if(dia_semana != 7)
                                {
                                    dia_semana++;
                                }
                                else
                                {
                                    dia_semana = 1;
                                }
                            }
                        }
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 8)
                    {
                        int i, id8;
                        
                        Empregado funcionario8 = new Empregado();
                        System.out.println("->Digite undo ou redo: ");
                        String acao = input.nextLine();
                        
                        if(acao.equals("undo"))
                        {
                            funcionario8 = undo.pop();
                            id8 = funcionario8.getId();
                            
                            //System.out.println("vendas antes de atribuir" + funcionario8.getValor_venda().getValor_vendas());
                            
                            Empregado funcionario8_1 = new Empregado();
                            
                            for(i = 0; i < Empregados.size(); i++)
                            {
                                funcionario8_1 = Empregados.get(i);
                                if(funcionario8_1.getId() == id8)
                                {
                                    if(funcionario8_1.getAcao().equals("add"))
                                    {
                                        funcionario8_1.setAcao("removed");
                                        redo.push(funcionario8_1);
                                        Empregados.remove(funcionario8_1);
                                    }
                                    else
                                    {
                                        //System.out.println("aquiii");
                                        redo.push(funcionario8_1);
                                        Empregados.remove(funcionario8_1);
                                        Empregados.add(funcionario8);
                                        break;
                                    }
                                }
                                if(i == Empregados.size() - 1)
                                {
                                    System.out.println("->Digite opcao 1 para recolocar empregado no sistema...");
                                    funcionario8_1.setAcao("add");
                                    redo.push(funcionario8_1);
//                                  Empregados.add(funcionario8_1);
                                }
                            }
                        }
                        else if(acao.equals("redo"))
                        {
                           funcionario8 = redo.pop();
                            
                           Empregado funcionario8_1 = new Empregado();
                           
                           if(funcionario8.getAcao().equals("add"))
                           {
                               //System.out.println("aquiiii 2");
                               for(i = 0; i < Empregados.size(); i++)
                               {
                                    funcionario8_1 = Empregados.get(i);
                                    if(funcionario8_1.getId() == cont)
                                    {
                                        funcionario8_1.setAcao("removed");
                                        undo.push(funcionario8_1);
                                        Empregados.remove(funcionario8_1);
                                    }
                               }
                           }
                           else
                           {
                               id8 = funcionario8.getId();
                                for(i = 0; i < Empregados.size(); i++)
                                {
                                    funcionario8_1 = Empregados.get(i);
                                    if(funcionario8_1.getId() == id8)
                                    {
                                        undo.push(funcionario8_1);
                                        Empregados.remove(funcionario8_1);
                                        Empregados.add(funcionario8);
                                        break;
                                    }
                                    if(i == Empregados.size() - 1)
                                    {
                                         System.out.println("->Digite opcao 1 para recolocar empregado no sistema...");
     //                                  funcionario8_1.setAcao("add");
     //                                  redo.push(funcionario8_1);
     //                                  Empregados.add(funcionario8_1);
                                    }
                                 }
                            }
                        }
                        System.out.println("---------------------------------------------");
                    }
                    if(opcao == 9)
                    {
                        String dia_s, dia_s15;
                        
                        int dia_sem, dia_sem_15, dia_m;
                        dia_sem = agenda.getDia_semana();
                        dia_sem_15 = agenda.getDia_semana15();
                        dia_m = agenda.getDia_mes();
                        System.out.println();
                        System.out.println("                         AGENDA\n");
                        System.out.println("A agenda de pagamento esta organizada da seguinte forma: \n");
                        //-----------------------------Horistas----------------------------------------
                        if(dia_sem == 1)
                        {
                            dia_s = "Domingo";
                            System.out.println("-Os horistas sao pagos toda semana no " + dia_s + ".");
                        }
                        else if(dia_sem == 2)
                        {    
                            dia_s = "Segunda-Feira";
                            System.out.println("-Os horistas sao pagos toda semana na " + dia_s + ".");
                        }
                        else if(dia_sem == 3)
                        {    
                            dia_s = "Terca-Feira";
                            System.out.println("-Os horistas sao pagos toda semana na " + dia_s + ".");
                        }
                        else if(dia_sem == 4)
                        {    
                            dia_s = "Quarta-Feira";
                            System.out.println("-Os horistas sao pagos toda semana na " + dia_s + ".");
                        }
                        else if(dia_sem == 5)
                        { 
                            dia_s = "Quinta-Feira";
                            System.out.println("-Os horistas sao pagos toda semana na " + dia_s + ".");
                        }
                        else if(dia_sem == 6)
                        {    
                            dia_s = "Sexta-Feira";
                            System.out.println("-Os horistas sao pagos toda semana na " + dia_s + ".");
                        }
                        else if(dia_sem == 7)
                        {    
                            dia_s = "Sabado";
                            System.out.println("-Os horistas sao pagos toda semana no " + dia_s + ".");
                        }
                        System.out.println();
                        //-------------------------------comissionados-------------------------------------
                        
                        if(dia_sem_15 == 1)
                        {
                            dia_s15 = "Domingo";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas no " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 2)
                        {    
                            dia_s15 = "Segunda-Feira";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas na " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 3)
                        {    
                            dia_s15 = "Terca-Feira";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas na " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 4)
                        {    
                            dia_s15 = "Quarta-Feira";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas na " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 5)
                        { 
                            dia_s15 = "Quinta-Feira";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas na " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 6)
                        {    
                            dia_s15 = "Sexta-Feira";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas na " + dia_s15 + ".");
                        }
                        else if(dia_sem_15 == 7)
                        {    
                            dia_s15 = "Sabado";
                            System.out.println("-Os comissionados sao pagos a cada duas semanas no " + dia_s15 + ".");
                        }
                        System.out.println();
                        //-------------------------------assalariado-------------------------------------
                        
                        if(dia_m == 50)
                        {
                            System.out.println("-Os assalariados sao pagos todo mês no ultimo dia util do mês.");
                        }
                        else
                        {
                            System.out.println("-Os assalariados sao pagos todo mês no dia " + dia_m + ".");
                        }
                        System.out.println();
                        System.out.println("---------------------------------------------");
                        System.out.println();
                    }
                    if(opcao == 10)
                    {
                        int edit_pagamento;
                        System.out.println();
                        System.out.println("Crie uma nova agenda, alterando as datas de pagamento dos funcionarios!");
                        System.out.println();
                        System.out.println("Se deseja alterar a data do mês a se pagar o assalariado, digite 1: ");
                        System.out.println("Se deseja alterar o dia da semana a se pagar o horista, digite 2: ");
                        System.out.println("Se deseja alterar o dia da semana a se pagar o comissionado, digite 3: ");
                        System.out.println("Opcao: ");
                        edit_pagamento = input.nextInt();
                        System.out.println();
                        
                        if(edit_pagamento == 1)
                        {
                            System.out.println("Digite o novo dia do mês, sendo  50, o ultimo dia util do mes...");
                            agenda.setDia_mes(input.nextInt());
                        }
                        else if(edit_pagamento == 2)
                        {
                            System.out.println("Digite o novo dia da semana da forma a seguir:\nSegunda-Feira: 2\nTerca-Feira: 3\nQuarta-Feira: 4\nQuinta-Feira: 5\nSexta-Feira: 6");
                             System.out.println("Dia: ");
                            agenda.setDia_semana(input.nextInt());
                        }
                        else if(edit_pagamento == 3)
                        {
                            System.out.println("Digite o novo dia da semana da forma a seguir:\nSegunda-Feira: 2\nTerca-Feira: 3\nQuarta-Feira: 4\nQuinta-Feira: 5\nSexta-Feira: 6");
                            System.out.println("Dia: ");
                            agenda.setDia_semana15(input.nextInt());
                        }
                        int k;
                        Empregado funcionario10 = new Empregado();
                        for(k = 0; k < Empregados.size(); k++)
                        {
                            funcionario10 = Empregados.get(k);
                            if(funcionario10.getTipo().equals("assalariado"))
                            {
                                funcionario10.setDia_mes_1(agenda.getDia_mes());
                            }
                            else if(funcionario10.getTipo().equals("horista"))
                            {
                                funcionario10.setDia_semana_1(agenda.getDia_semana());
                            }
                            else if(funcionario10.getTipo().equals("comissionado"))
                            {
                                funcionario10.setDia_semana15(agenda.getDia_semana15());
                            }
                        }
                        System.out.println();
                        System.out.println("Operação concluida com sucesso...\n");
                        System.out.println("---------------------------------------------");
                    }
                    
//                    System.out.println();
//                    Empregado funcionario12 = new Empregado();
//                    int j;      
//                    for(j = 0; j < Empregados.size(); j++)
//                    {
//                        funcionario12 = Empregados.get(j);
//                        System.out.println(funcionario12.getName());
//                    }
                    System.out.println();
                    System.out.println("Digite a proxima funcao caso deseje execultar, caso contrário, digite 11 para fechar o programa...");
                    System.out.println();
                    System.out.print("Digite a opção de qual função deseja execultar...\n");
                    System.out.println();
                    System.out.print("1 . Adição de um empregado\n");
                    System.out.print("2 . Remoção de um empregado\n");
                    System.out.print("3 . Lançar um Cartão de Ponto\n");
                    System.out.print("4 . Lançar um Resultado Venda\n");
                    System.out.print("5 . Lançar uma taxa de serviço\n");
                    System.out.print("6 . Alterar detalhes de um empregado\n");
                    System.out.print("7 . Rodar a folha de pagamento para hoje\n");
                    System.out.print("8 . Undo/redo\n");
                    System.out.print("9 . Agenda de Pagamento\n");
                    System.out.print("10 . Criação de Novas Agendas de Pagamento\n");
                    System.out.println();
                    System.out.print("Opção: \n"); 
                }
        }
}
