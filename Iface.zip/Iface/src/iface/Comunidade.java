package iface;

import java.util.ArrayList;

public class Comunidade 
{
    String nome_comunidade;
    String descricao;
    String admin;
    String status;
    
    java.util.ArrayList<String> Membros = new java.util.ArrayList<String>();
    java.util.ArrayList<String> pedidos = new java.util.ArrayList<String>();

    public ArrayList<String> getPedidos() {
        return pedidos;
    }

    public void setPedidos(ArrayList<String> pedidos) {
        this.pedidos = pedidos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNome_comunidade() {
        return nome_comunidade;
    }

    public void setNome_comunidade(String nome_comunidade) {
        this.nome_comunidade = nome_comunidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public ArrayList<String> getMembros() {
        return Membros;
    }

    public void setMembros(ArrayList<String> Membros) {
        this.Membros = Membros;
    }
}
