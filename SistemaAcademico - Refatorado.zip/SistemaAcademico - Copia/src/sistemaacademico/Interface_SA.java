package sistemaacademico;

public interface Interface_SA {
    public int search_object(java.util.ArrayList<Object> list, String nome);
}
