package isoccer;

public interface Interface_func 
{
    void creat_funcionario(String tipo, java.util.ArrayList<Funcionario> Funcionarios);
}
