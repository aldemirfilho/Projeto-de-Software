package iterator_show;
/*
 * @author Aldemir Filho
 */
public class Iterator_show {
    public static void main(String[] args) {
        MenuItem [] menuItens = new MenuItem[4];
        java.util.ArrayList<MenuItem> menuitens2 = new java.util.ArrayList<MenuItem>();
        
        menuitens2.add(new MenuItem("Menu 1 list"));
        menuitens2.add(new MenuItem("Menu 2 list"));
        menuitens2.add(new MenuItem("Menu 3 list"));
        menuitens2.add(new MenuItem("Menu 4 list"));
        
         
        menuItens[0] = new MenuItem("Menu 1 array");
        menuItens[1] = new MenuItem("Menu 2 array");
        menuItens[2] = new MenuItem("Menu 3 array");
        menuItens[3] = new MenuItem("Menu 4 array");
         
        Iterator menuIterator_array = new MenuIterator_array(menuItens); //construtor array
        Iterator menuIterator_list = new MenuIterator_list(menuitens2); //construtor list
        
        System.out.println("----------ARRAY----------");
        while (menuIterator_array.hasNext()) {
            MenuItem menuItem = (MenuItem)menuIterator_array.next();
            System.out.println(menuItem.nome);
        }
        
        System.out.println("----------LIST----------");
        while (menuIterator_list.hasNext()) {
            MenuItem menuItem = (MenuItem)menuIterator_list.next();
            System.out.println(menuItem.nome);
        }
        System.out.println();
        MenuItem menuItem_array = (MenuItem)menuIterator_array.first();
        System.out.println("Primeiro array -> " + menuItem_array.nome);
        
        MenuItem menuItem_list = (MenuItem)menuIterator_list.first();
        System.out.println("Primeiro list -> " + menuItem_list.nome);
        
    }
    
}
