package iterator_show;
/*
 * @author Aldemir Filho
 */
public class MenuItem {
    String nome;
     
    MenuItem(String nome) {
        this.nome = nome;
    }
}
