package iterator_show;
/*
 * @author Aldemir Filho
 */
public class MenuIterator_array implements Iterator {
    MenuItem[] itens;
    int posicao = 0;
    
    //construtor
    public MenuIterator_array(MenuItem[] itens) {
        this.itens = itens;
    }
    
    @Override
    public Object first() {
        posicao = 0;
        MenuItem menuItem = itens[posicao];
        return menuItem;
    }
    
    @Override
    public boolean isDone() {
        return posicao == itens.length;
    }
     
    @Override
    public Object next() {
        MenuItem menuItem = itens[posicao];
        posicao++;
        return menuItem;
    }
     
    @Override
    public boolean hasNext() {
        if (posicao >= itens.length || itens[posicao] == null) {
            return false;
        } else {
            return true;
        }
    }
}
