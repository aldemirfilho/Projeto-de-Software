package iterator_show;
/*
 * @author Aldemir Filho
 */
public class MenuIterator_list implements Iterator {
    java.util.ArrayList<MenuItem> itens;
    int posicao = 0;
    
    //construtor
    public MenuIterator_list(java.util.ArrayList<MenuItem> itens) {
        this.itens = itens;
    }
    
    @Override
    public Object first() {
        posicao = 0;
        MenuItem menuItem = itens.get(posicao);
        return menuItem;
    }
    
    @Override
    public boolean isDone() {
        return posicao == itens.size();
    }
     
    @Override
    public Object next() {
        MenuItem menuItem = itens.get(posicao);
        posicao++;
        return menuItem;
    }
     
    @Override
    public boolean hasNext() {
        if (posicao >= itens.size() || itens.get(posicao) == null) {
            return false;
        } else {
            return true;
        }
    }
}
