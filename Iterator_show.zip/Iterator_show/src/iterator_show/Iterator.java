package iterator_show;
/*
 * @author Aldemir Filho
 */
public interface Iterator {
    boolean isDone();
    Object first();
    boolean hasNext();
    Object next();
}
