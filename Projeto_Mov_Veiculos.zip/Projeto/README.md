# Projeto P1 - CC3642
Projeto de Orienta��o a Objetos

Documenta��o em: dist/javadoc/index.html

Para dar a sensa��o de movimenta��o, deixe a janela de sa�da do netbeans no canto de baixo da tela, e a puxe at� o topo da tela.

O tempo de sleep � uma vari�vel, e a primeira coisa que o programa pede ao iniciar � que o usu�rio digite o tempo de sleep em ms. O programa rodou fluido com um Thread.sleep(1000) em todas vers�es.