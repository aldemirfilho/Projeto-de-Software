package p1;

import java.util.Random;

/**
 *
 * @author Aldemir Filho
 */
public enum NewEnum implements Strategy_Interface{
    Bicleta{
        @Override
        public void Incrementa(Contador cont, boolean soma) {
            cont.incrementaBicicleta(soma);
        }

        @Override
        public Veiculo adiciona(Random rand, String[] arrTipo, Contador cont, Mundo mundo) {
            Veiculo veiculo = new Bicicleta(mundo, rand.nextInt(mundo.getTamanho_x()), rand.nextInt(mundo.getTamanho_y()));
            cont.incrementaBicicleta(true);
            return veiculo;
        }

        @Override
        public void contar(Contador cont) {
            cont.setBicicleta(cont.getBicicleta() + 1);
        }
            
    },
    Moto{
        @Override
        public void Incrementa(Contador cont, boolean soma) {
            cont.incrementaMoto(soma);
        }

        @Override
        public Veiculo adiciona(Random rand, String[] arrTipo, Contador cont, Mundo mundo) {
            Veiculo veiculo = new Moto(mundo, rand.nextInt(mundo.getTamanho_x()), rand.nextInt(mundo.getTamanho_y()), arrTipo[rand.nextInt(arrTipo.length)]);
            cont.incrementaMoto(true);
            return veiculo;
        }

        @Override
        public void contar(Contador cont) {
            cont.setMoto(cont.getMoto() + 1);
        }
    },
    Caminhao{
        @Override
        public void Incrementa(Contador cont, boolean soma) {
            cont.incrementaCaminhao(soma);
        }

        @Override
        public Veiculo adiciona(Random rand, String[] arrTipo, Contador cont, Mundo mundo) {
            Veiculo veiculo = new Caminhao(mundo, rand.nextInt(mundo.getTamanho_x()), rand.nextInt(mundo.getTamanho_y()), rand.nextInt(7000)+1000);
            cont.incrementaCaminhao(true);
            return veiculo;
        }

        @Override
        public void contar(Contador cont) {
            cont.setCaminhao(cont.getCaminhao() + 1);
        }
    },
    Carro{
        @Override
        public void Incrementa(Contador cont, boolean soma) {
            cont.incrementaCarro(soma);
        }

        @Override
        public Veiculo adiciona(Random rand, String[] arrTipo, Contador cont, Mundo mundo) {
            Veiculo veiculo = new Carro(mundo, rand.nextInt(mundo.getTamanho_x()), rand.nextInt(mundo.getTamanho_y()), rand.nextInt(5)+1);
            cont.incrementaCarro(true);
            return veiculo;
        }

        @Override
        public void contar(Contador cont) {
            cont.setCarro(cont.getCarro() + 1);
        }
    }
}
