package p1;

import java.util.Random;

/**
 *
 * @author Aldemir Filho
 */
public interface Strategy_Interface {
    public void Incrementa(Contador contador, boolean soma);
    public Veiculo adiciona(Random rand, String[] arrTipo, Contador cont, Mundo mundo);
    public void contar(Contador cont);
}
