public class Command_Plano_three implements Command_Plano{

    @Override
    public int execute() {
        return 60;
    }
}
