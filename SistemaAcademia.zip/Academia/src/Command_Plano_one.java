public class Command_Plano_one implements Command_Plano{

    @Override
    public int execute() {
        return 130;
    }
}
