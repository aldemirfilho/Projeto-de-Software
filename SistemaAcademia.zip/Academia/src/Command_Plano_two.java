public class Command_Plano_two implements Command_Plano{

    @Override
    public int execute() {
        return 40;
    }
}
