public interface Command_Plano {
    public int execute();
}
