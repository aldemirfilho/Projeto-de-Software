public interface Command_Plano2 {
    public String execute();
}
