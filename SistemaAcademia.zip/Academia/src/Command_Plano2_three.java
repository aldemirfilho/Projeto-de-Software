public class Command_Plano2_three implements Command_Plano2{

    @Override
    public String execute() {
        return "Plano Padrão";
    }
}
