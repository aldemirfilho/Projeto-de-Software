public class Command_Plano_four implements Command_Plano{

    @Override
    public int execute() {
        return 100;
    }
}
