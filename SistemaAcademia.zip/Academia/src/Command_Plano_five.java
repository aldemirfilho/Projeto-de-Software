public class Command_Plano_five implements Command_Plano{

    @Override
    public int execute() {
       return 80;
    }
}
